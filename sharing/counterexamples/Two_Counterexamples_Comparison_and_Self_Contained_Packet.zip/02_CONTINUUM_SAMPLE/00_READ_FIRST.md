# Counterexample 2: continuum future overlaps at two sampled events

## Fixed model and observation
R=(0,1)^2 in null coordinates (u,v), ds^2=-du dv, dV=du dv/2. For x in R, A_x=J+(x) intersect R is a continuum region. Its volume is a_x=(1-u_x)(1-v_x)/2. The common-future volume c_xy=(1-max(u_x,u_y))(1-max(v_x,v_y))/2. K_xy=c_xy/sqrt(a_x a_y). This does not count successors within the stored event sample.

## Construction, equality and invariant certificate
P=[(1/2,1/2),(3/4,3/4)] is a chain. Q=[(1/2,3/4),(3/4,1/2)] is an antichain. P future volumes are [1/8,1/32]; Q volumes are [1/16,1/16]; both common-future volumes are 1/32. Both K are [[1,1/2],[1/2,1]]. Strict comparable-pair counts are one versus zero, an order-isomorphism invariant. Two events are minimal for this induced-order ambiguity.

## Geometric data, not abstract-order invariants
Future-volume multisets differ. In (t,z)=((u+v)/2,(u-v)/2), squared separations are -1/16 and +1/16: timelike versus spacelike. These are geometric quantities in the fixed model, not general abstract-poset invariants.

## What restores recovery
Individually attached future volumes together with K recover causal order by x<=y iff K_xy^2 a_x=a_y. This says c_xy=a_y. In the open diamond, the rectangular future of y is contained in that of x exactly when both coordinates of x are <= those of y; violation removes a positive-volume strip. An unordered multiset is not individually attached data. This witness's differing volume multisets do not settle an augmented unordered-multiset recovery question.
E10 assumes the entire domain and a surjective exact K-preserving correspondence; finite samples do not satisfy that hypothesis. Related original E9/E10 proofs are included here for optional context, with their dependencies stated.

## Run this folder independently
With Python 3, run `python E11/check.py`, then `python E11/independent_verify.py`. These unchanged original scripts write E11/results; if preserving supplied outputs, run on a copy. The packet-level reproduce_all.py automatically uses temporary copies. Both scripts use only the standard library. E11/PROOFS.md supplies the complete direct proof; results/main.json and independent.json contain exact certificates.

## Provenance and limits
Original plan, scripts, stdout/stderr, claim ledger and source-access records are retained. CURRENT_E11_FREEZE.json establishes the later frozen status; an older completed_pending_freeze statement in original documents is historical. Both samples inhabit the same diamond. No detector model, black-hole mechanism, general-spacetime uniqueness or literature novelty is established.
