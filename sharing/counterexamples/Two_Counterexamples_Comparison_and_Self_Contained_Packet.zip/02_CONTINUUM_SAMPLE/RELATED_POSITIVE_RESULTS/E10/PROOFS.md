# E10: Complete-interior overlap rigidity

## Result: proved with a stated theorem dependency
For the same fixed finite open 1+1 Minkowski diamond, every bijection of its ENTIRE interior preserving exact normalized future overlaps K preserves causal order. Future volumes need not be separately supplied. The proof uses a published affine-isometry theorem with its hypotheses checked. It is not a finite-sample reconstruction result or an independent reproof of that external theorem.

## Predetermined target and assumptions
All interior events and all exact pair overlaps are available; an admissible competitor covers the same full model domain. The flat diamond and standard volume measure are assumed. No numerical experiment, sampled-event variant, curved-spacetime extension or physics model was run. E9 remains unchanged historical evidence; Audit 10 v144 is untouched.

## Logarithmic coordinates
Write S = u_1-u_0 and T = v_1-v_0. For interior x let s_x = u_1-u_x and r_x = v_1-v_x. Define p_x = -log(s_x/S) and q_x = -log(r_x/T). This is a bijection of the full interior onto Q = (0,infinity)^2. Causal order is coordinatewise increasing in p,q. The future-volume fraction is a_x/V(R) = exp[-(p_x+q_x)].

## Overlaps become a metric
E9 gives K(x,y) = min(s_x,s_y) min(r_x,r_y)/sqrt(s_x r_x s_y r_y). For positive s,sprime, min(s,sprime)/sqrt(s sprime) = exp[-|log s-log sprime|/2]. Thus K(x,y) = exp[-(|p_x-p_y|+|q_x-q_y|)/2]. The data therefore define the L1 metric D(x,y) = -2 log K(x,y). K is positive, and distinct interior points have K < 1. Any full-interior K-preserving bijection induces a surjective L1 isometry F:Q -> Q.

## External theorem and hypothesis audit
Mori and Ozawa, arXiv:1804.10674v3, Theorem 2, proves the strong Mankiewicz property for convex bodies in a Banach space whose unit-ball extreme points have a convex hull with nonempty interior. For X = real R^2 with L1 norm, the unit-ball extreme points are +/-e_1 and +/-e_2, whose convex hull is the entire unit ball and has nonempty interior. Q is convex with nonempty interior; the range Q is convex; F is surjective and isometric. Hence that theorem applies and F is affine. [MO, p. 2, Theorem 2; proof pp. 2-3]

# Classification and reconstruction consequence

## Affine extension in this case
Write F(z) = Az+b on Q. Because Q is open, fix z in Q and, for any w, choose small epsilon > 0 with z+epsilon w in Q. Isometry gives epsilon ||Aw||_1 = epsilon ||w||_1. Thus A preserves the L1 norm on all of R^2; it is injective and hence invertible. It maps the unit ball onto itself and permutes its extreme points. Therefore A is a signed coordinate permutation.

## The full quadrant eliminates extra symmetries
A negative coordinate sign would make that output coordinate tend to minus infinity as its input coordinate tends to plus infinity, contradicting F(Q) subset Q. All signs are positive. Then F(Q) = b+Q. Equality with Q forces b_1=b_2=0, since the infimum of each coordinate in Q is zero. Consequently F is either the identity or the coordinate swap (p,q) -> (q,p). Both possibilities actually preserve K and causal order.

## What complete K determines
These two possibilities preserve coordinatewise order and p+q. Hence complete K determines the causal order and the normalized future-volume function a_x/V(R), uniquely under the full-diamond model promise. One may choose any isometric representation of the data onto Q; the definitions are independent of that choice because the only ambiguity is coordinate swap. This is a uniqueness result, not an implemented finite-data reconstruction algorithm. If total diamond volume is supplied, absolute a_x follow; without it, K cannot fix an overall volume scale.

## Scope that must not be broadened
Surjectivity onto the full open quadrant is essential to the proof. For sampled events, neither convex-body hypotheses nor full-quadrant boundary constraints follow. E10 therefore asserts nothing about finite or incomplete samples. It does not establish uniqueness among arbitrary curved spacetimes, arbitrary observation regions or unknown dimensions. It does not contradict the finite-poset G collision, claim metric uniqueness for general spacetime, or supply detector access and black-hole dynamics.

## Dependency, provenance and next target
The imported affine theorem is credited to Mori-Ozawa; their text attributes the earlier convex-body affine result to Mankiewicz (1972). The original 1972 paper was not retrieved, and no claim of independently reproducing its proof is made. Only the selected theorem and its displayed proof were inspected; unrelated C*-algebra conclusions are not imported. E10 is completed pending freeze. A finite-sample overlap-only test is a separate possible next target; no E11 has begun.
