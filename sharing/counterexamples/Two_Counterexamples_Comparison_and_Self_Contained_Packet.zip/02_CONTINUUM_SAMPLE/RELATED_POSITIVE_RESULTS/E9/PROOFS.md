# E9: Order recovery inside a causal diamond

## Result: proved for the specified case
Exact normalized future overlaps K, together with positive future volumes individually attached to the query events, recover causal order inside a fixed finite open diamond in 1+1 Minkowski spacetime. The criterion is x <= y if and only if K(x,y)^2 a_x = a_y. This is a direct continuum proof for this domain, not an import of a finite-poset theorem.

## Predetermined scope
The target and exclusions were recorded before the proof. Data are exact; volumes are attached to their event labels, not supplied as an unordered multiset. We assume the fixed flat diamond and its standard spacetime-volume measure. All query events lie strictly inside. No numerical experiment, curved-spacetime extension, detector model, or overlap-only attack was run.

## Geometry and volume
Set light speed to one and use ds^2 = -dt^2 + dz^2. Introduce u = t+z and v = t-z; then ds^2 = -du dv and dt dz = (1/2) du dv in absolute Jacobian. A finite open diamond is R = (u_0,u_1) times (v_0,v_1) in null coordinates. Future causal precedence is u_x <= u_y and v_x <= v_y, including equality and null separation.

## Future and intersection formulas
For interior x, the truncated causal future A_x = J+(x) intersect R is a rectangle, with boundary inclusions irrelevant to volume. Put s_x = u_1-u_x > 0 and r_x = v_1-v_x > 0. Then a_x = V(A_x) = s_x r_x/2. For x,y, c_xy = V(A_x intersect A_y) = min(s_x,s_y) min(r_x,r_y)/2. Finally K(x,y) = c_xy/sqrt(a_x a_y), with positive denominators. These formulas supply the entire proof.

## Source and provenance
Carroll chapter 1 is used only for standard flat-spacetime and causal-cone background. The diamond, null-coordinate Jacobian, rectangle formulas and recovery proof are derived here. E1-E8 parent files remain byte-identical; Audit 10 v144 is frozen and untouched. E9 is completed, pending freeze.

# Proof, zero-volume gap and limits

## Forward implication
If x <= y, then u_x <= u_y and v_x <= v_y, so s_x >= s_y and r_x >= r_y. The intersection formula gives c_xy = s_y r_y/2 = a_y. Hence K(x,y)^2 a_x = c_xy^2/a_y = a_y.

## Reverse implication
Suppose K(x,y)^2 a_x = a_y. Since a_y > 0 and c_xy >= 0, c_xy^2 = a_y^2 implies c_xy = a_y. Divide the intersection formula by a_y to obtain [min(s_x,s_y)/s_y] [min(r_x,r_y)/r_y] = 1. Each factor lies in (0,1]. Their product can equal one only if both equal one. Thus s_x >= s_y and r_x >= r_y, equivalently u_x <= u_y and v_x <= v_y. Therefore x <= y.

## Why zero-volume differences do not defeat this case
If u_x > u_y, then s_x < s_y and min(s_x,s_y)/s_y < 1. The other positive factor is at most one, so c_xy < a_y. The same argument holds if v_x > v_y. Every failure of causal precedence therefore produces a positive-volume deficit inside this diamond. Although rectangle edges have zero volume, they cannot disguise an interior coordinate inequality. This conclusion was proved for these rectangles; it is not assumed for arbitrary future sets.

## Reconstruction meaning
Given an abstract index set of events with this model promised, define i <=_data j exactly when K_ij^2 a_i = a_j. It equals the actual causal order, so two event families in such diamonds related by a bijection preserving K and attached a have the same recovered order under that bijection. The proof works for any subset of interior events whose pair data and attached volumes are exact; full interior coverage yields the full interior order. It does not recover unobserved events from a finite subset.

## Excluded claims and next question
Upper future-boundary events can have a_x = 0 and are excluded; dividing by their volumes is invalid. Other regions, curved spacetimes, noisy samples and unordered volumes are not covered. No metric uniqueness, physical detector access, black-hole mechanism or novelty claim is established. K alone remains untested by this attack. After freeze, that is a possible next question within the same specified geometry; no E10 has begun.
