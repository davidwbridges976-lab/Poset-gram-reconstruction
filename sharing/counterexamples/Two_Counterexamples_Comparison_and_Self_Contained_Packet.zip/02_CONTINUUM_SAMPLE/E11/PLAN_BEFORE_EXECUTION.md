# E11 predetermined finite-sample certificate
4 October 2026. One exact rational two-sample witness, no search or simulation.

Same fixed open null-coordinate unit diamond R=(0,1)^2, metric -du dv, volume du dv/2. Continuum futures intersect R, not sampled-event upset counts. Sample P: (1/2,1/2),(3/4,3/4). Sample Q: (1/2,3/4),(3/4,1/2). Test K equality and non-isomorphic induced causal orders. Compute exact K squared and positive-root values; attached volumes not supplied as overlap-only input.

Main verifier: rectangular continuum futures, volume intersections, coordinate causal order. Independent verifier: explicit t,z intervals and separately assembled rectangle counts/ratios without main helper imports. Save both scripts and stdout/stderr, exact outputs, comparisons and any failures. Claim finite-sample insufficiency only if exact checks agree; otherwise retain failure. No broader embedding, black-hole claim or import into Audit 10. Do not run a new sample/variant after this witness. Deliver PDF/ZIP before next attack.
