# E11: Finite-sample overlap collision

## Result: exact counterexample
Two two-event samples in the SAME fixed open 1+1 Minkowski diamond have identical continuum normalized future overlaps K but non-isomorphic induced causal orders. Thus K alone does not generally recover order from finite samples in this geometry. The full-interior E10 result remains valid.

## Observation map and fixed geometry
Use R=(0,1) times (0,1) in null coordinates (u,v), metric ds^2=-du dv and volume measure du dv/2. K uses full continuum causal futures intersected with R. It does not count events in the sample. For an interior event x, a_x=(1-u_x)(1-v_x)/2; c_xy=(1-max(u_x,u_y))(1-max(v_x,v_y))/2; K_xy=c_xy/sqrt(a_x a_y).

## The two samples
P_1=(1/2,1/2), P_2=(3/4,3/4). Both coordinates increase, so P_1 strictly precedes P_2.
Q_1=(1/2,3/4), Q_2=(3/4,1/2). One coordinate increases and the other decreases, so Q_1 and Q_2 are incomparable. All four events are strictly inside the same diamond.

## Exact overlap certificate
P future volumes: a_1=1/8, a_2=1/32. Q future volumes: b_1=b_2=1/16. In both samples the offdiagonal intersection volume is 1/32. Thus K_P(1,2)=(1/32)/sqrt((1/8)(1/32))=1/2, and K_Q(1,2)=(1/32)/sqrt((1/16)(1/16))=1/2. Both diagonals are 1. Both matrices are [[1,1/2],[1/2,1]]. Positive square roots are fixed by nonnegative overlap volumes.

## Non-isomorphism and minimal size
The induced poset on P has one strict comparable pair; Q has zero. No relabeling can change that count, so the orders are not isomorphic. A one-event induced order has only one isomorphism type. Consequently two is the smallest possible sample size for this type of causal-order ambiguity. This minimality concerns sampled induced orders, not the size of Audit 10 poset collisions.

# Checks, scope and what survives

## Independent geometric check
In (t,z), with t=(u+v)/2 and z=(u-v)/2, P is (1/2,0),(3/4,0): squared interval -1/16. Q is (5/8,-1/8),(5/8,1/8): squared interval +1/16. These establish timelike order versus spacelike separation directly. A separate rational verifier computes overlap ratios from future-side lengths and agrees with the main rectangular-future calculation.

## Why E10 is not contradicted
Equal K on two stored query events need not extend to a K-preserving bijection of the entire diamond. E10 classified surjective full-domain isometries, and this two-point correspondence does not satisfy its hypotheses. Complete coverage and finite sampling therefore have different recovery guarantees.

## Why E9 survives
The attached future-volume data differ: P has 1/8 and 1/32, Q has 1/16 and 1/16. With those individually attached volumes, E9 recovers each actual order through K_xy^2 a_x=a_y. This witness does not refute recovery with attached volumes, and does not address an unordered-volume-multiset question.

## Executed provenance
The sample and criteria were recorded in PLAN_BEFORE_EXECUTION.md. Main check.py and independent_verify.py were each executed once with standard-library Fraction arithmetic. Both passed; no search, simulation, variant or rerun occurred. Original stdout/stderr, two exact JSON certificates and their field comparison are retained. Build_packet.py is executed artifact authoring, not an additional numerical experiment.

## Physical and import limits
This is a geometric counterexample for exact continuum overlap data at finitely many query events. No hardware observation, detector model, black-hole mechanism or embedding of the original 16-element pair was asserted. E1-E10 evidence is preserved byte-identically and Audit 10 v144 remains untouched. E11 is completed pending freeze.

## Reader map and next decision
Read the proof on page 1, then the exact scripts and results under E11/. Check the observation-map distinction before comparing with finite poset counts. No E12 is queued: after freeze, discuss whether to study recovery guarantees for additional data or broaden geometry, with a new predeclared target. Do not run either as part of this certificate.
