from fractions import Fraction as F
from pathlib import Path
import json
samples={'P':[(F(1,2),F(1,2)),(F(3,4),F(3,4))],'Q':[(F(1,2),F(3,4)),(F(3,4),F(1,2))]}
def vol(x):return (1-x[0])*(1-x[1])/2
def common(x,y):return (1-max(x[0],y[0]))*(1-max(x[1],y[1]))/2
result={}
for n,pts in samples.items():
 a=[vol(x) for x in pts];c=[[common(x,y) for y in pts] for x in pts];k2=[[c[i][j]**2/(a[i]*a[j]) for j in range(2)] for i in range(2)]
 order=[[x[0]<=y[0] and x[1]<=y[1] for y in pts] for x in pts]
 assert all(0<u<1 and 0<v<1 for u,v in pts)
 result[n]={'points_uv':[[str(u),str(v)] for u,v in pts],'volumes':list(map(str,a)),'intersection_volumes':[[str(x) for x in row] for row in c],'K_squared':[[str(x) for x in row] for row in k2],'order':order}
assert result['P']['K_squared']==result['Q']['K_squared']==[['1','1/4'],['1/4','1']]
assert result['P']['order']==[[True,True],[False,True]]
assert result['Q']['order']==[[True,False],[False,True]]
result['verdict']={'K_equal':True,'K':[['1','1/2'],['1/2','1']],'nonisomorphic':'P has one strict comparable pair; Q has none'}
p=Path(__file__).parent/'results';p.mkdir(exist_ok=True);(p/'main.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS: exact K equality and chain/antichain distinction')
