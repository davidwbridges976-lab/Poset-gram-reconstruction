from fractions import Fraction as R
from pathlib import Path
import json
# Independently specified (t,z) events, with u=t+z and v=t-z.
events={'P':[(R(1,2),R(0)),(R(3,4),R(0))],'Q':[(R(5,8),-R(1,8)),(R(5,8),R(1,8))]}
result={}
for name,pts in events.items():
 (t0,z0),(t1,z1)=pts;dt=t1-t0;dz=z1-z0
 interval=-dt*dt+dz*dz
 order=[[j==i or (pts[j][0]-pts[i][0]>=abs(pts[j][1]-pts[i][1])) for j in range(2)] for i in range(2)]
 sides=[(1-t-z,1-t+z) for t,z in pts];areas=[w*h/2 for w,h in sides]
 # Intersections of intervals ending at the same upper endpoints.
 shared=sorted([sides[0][0],sides[1][0]])[0]*sorted([sides[0][1],sides[1][1]])[0]/2
 ratio=shared*shared/(areas[0]*areas[1]);assert ratio==R(1,4)
 result[name]={'interval_squared':str(interval),'volumes':list(map(str,areas)),'intersection_volume':str(shared),'K_squared_offdiagonal':str(ratio),'order':order}
assert result['P']['interval_squared']=='-1/16'
assert result['Q']['interval_squared']=='1/16'
assert result['P']['order']==[[True,True],[False,True]] and result['Q']['order']==[[True,False],[False,True]]
p=Path(__file__).parent/'results';p.mkdir(exist_ok=True);(p/'independent.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS: independent interval and overlap certificate')
