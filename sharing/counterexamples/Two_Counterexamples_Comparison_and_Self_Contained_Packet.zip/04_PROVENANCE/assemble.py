from pathlib import Path
import shutil,json,hashlib,subprocess,sys,zipfile
root=Path(__file__).resolve().parent;pack=root/'packet';src=root.parent/'scaling_work/source';prior=root.parent/'scaling_work/package'
for a,b in [('01_FINITE_POSET','01_FINITE_POSET'),('02_CONTINUUM_SAMPLE','02_CONTINUUM_SAMPLE'),('03_CONTEXT','02_CONTINUUM_SAMPLE/RELATED_POSITIVE_RESULTS')]:shutil.copytree(src/a,pack/b,dirs_exist_ok=True)
shutil.copytree(prior/'AUDIT',pack/'00_COMPARISON/AUDIT',dirs_exist_ok=True)
(pack/'01_FINITE_POSET/check_invariants.py').write_text('''"""New reader certificate extraction, not a discovery or general search."""
from pathlib import Path
import json
r=Path(__file__).resolve().parent
x=json.loads((r/'core/counterexample_input.json').read_text());out={}
for name,key in [('P','source_zeta'),('Q','candidate_zeta')]:
 Z=x[key];n=len(Z);u=list(map(sum,Z));d=[sum(Z[j][i] for j in range(n)) for i in range(n)]
 out[name]={'element_count':n,'upset_sizes':u,'downset_sizes':d,'upset_size_multiset':sorted(u),'downset_size_multiset':sorted(d),'upset_two_downset_sizes':sorted(d[i] for i in range(n) if u[i]==2),'comparability_degree_multiset':sorted(u[i]+d[i]-2 for i in range(n)),'strict_comparable_pair_count':sum(u)-n}
assert out['P']['upset_two_downset_sizes']==[5,8,9,10]
assert out['Q']['upset_two_downset_sizes']==[6,7,8,11]
assert out['P']['comparability_degree_multiset']!=out['Q']['comparability_degree_multiset']
print(json.dumps(out,indent=2))
''')
v=subprocess.run([sys.executable,str(pack/'01_FINITE_POSET/check_invariants.py')],capture_output=True,text=True);assert v.returncode==0
(pack/'01_FINITE_POSET/READER_INVARIANTS.json').write_text(v.stdout);(pack/'01_FINITE_POSET/READER_INVARIANTS.stderr.txt').write_text(v.stderr)
inv=json.loads(v.stdout)
finite='''# Counterexample 1: finite-poset normalized overlaps

## Definitions and claim
For a finite poset, U(x)={y:x<=y}, d(x)=|U(x)|, H_xy=|U(x) intersect U(y)|, G_xy=H_xy/sqrt(d(x)d(y)). Self-membership is included. Two nonisomorphic 16-element orders have exactly equal G under the supplied labels, disproving universal G-only recovery.

## Construction and proof
Construction_and_Proof.pdf gives both orders and a complete block proof of equal G. core/counterexample_input.json contains their full 16x16 zeta matrices. Two Boolean sectors use phi=[0,1,1,3,1,3,5,7]. P uses inclusion and cross relation phi(X) subset Y; Q uses reverse inclusion and cross relation Y subset phi(X); no W-to-E relations.

## Invariants: what agrees and what differs
Both have 16 elements and 65 strict comparable pairs. The normalized matrix agrees at every labeled pair. The upset-size multisets agree (although attached vectors differ). The joint upset/downset information differs: among upset-size-two elements, P has downset sizes [5,8,9,10], Q has [6,7,8,11]. This is an order-isomorphism invariant and certifies nonisomorphism.
Comparability degree counts distinct comparable other elements, so c(x)=|U(x)|+|downset(x)|-2. Their degree multisets differ; see READER_INVARIANTS.json for exact vectors and multisets. This witness therefore does not refute G plus unordered comparability-degree-multiset recovery.

## What restores recovery
G plus individually attached upset sizes recovers the order: x<=y iff G_xy^2 d_x=d_y. Proof: this equality says H_xy^2=d_y^2, so H_xy=d_y; therefore U(y) subset U(x), which is equivalent to x<=y. An unordered size multiset is not the same as individually attached sizes. Comparability degrees are also different quantities.

## Run this folder independently
With Python 3, run `python verify_counterexample.py` to check poset axioms, all 256 exact squared Gram entries and nonisomorphism. Run `python check_invariants.py` to display the inventory. Both need only the standard library and the files in this folder. The original reader verifier is retained unchanged; check_invariants.py is a new reader extraction.

## Provenance and limits
Original_Reader_Run.json retains original verification plus related historical checks; the extra scripts named in that historical record are not needed for this witness. The construction PDF records a corrected historical element label. No 16-element minimality or literature novelty claim is made. Audit10 remains frozen at v144; this organization does not promote new mathematics.
'''
assert inv['P']['strict_comparable_pair_count']==inv['Q']['strict_comparable_pair_count']==65
assert inv['P']['upset_size_multiset']==inv['Q']['upset_size_multiset']
(pack/'01_FINITE_POSET/00_READ_FIRST.md').write_text(finite)
cont='''# Counterexample 2: continuum future overlaps at two sampled events

## Fixed model and observation
R=(0,1)^2 in null coordinates (u,v), ds^2=-du dv, dV=du dv/2. For x in R, A_x=J+(x) intersect R is a continuum region. Its volume is a_x=(1-u_x)(1-v_x)/2. The common-future volume c_xy=(1-max(u_x,u_y))(1-max(v_x,v_y))/2. K_xy=c_xy/sqrt(a_x a_y). This does not count successors within the stored event sample.

## Construction, equality and invariant certificate
P=[(1/2,1/2),(3/4,3/4)] is a chain. Q=[(1/2,3/4),(3/4,1/2)] is an antichain. P future volumes are [1/8,1/32]; Q volumes are [1/16,1/16]; both common-future volumes are 1/32. Both K are [[1,1/2],[1/2,1]]. Strict comparable-pair counts are one versus zero, an order-isomorphism invariant. Two events are minimal for this induced-order ambiguity.

## Geometric data, not abstract-order invariants
Future-volume multisets differ. In (t,z)=((u+v)/2,(u-v)/2), squared separations are -1/16 and +1/16: timelike versus spacelike. These are geometric quantities in the fixed model, not general abstract-poset invariants.

## What restores recovery
Individually attached future volumes together with K recover causal order by x<=y iff K_xy^2 a_x=a_y. This says c_xy=a_y. In the open diamond, the rectangular future of y is contained in that of x exactly when both coordinates of x are <= those of y; violation removes a positive-volume strip. An unordered multiset is not individually attached data. This witness's differing volume multisets do not settle an augmented unordered-multiset recovery question.
E10 assumes the entire domain and a surjective exact K-preserving correspondence; finite samples do not satisfy that hypothesis. Related original E9/E10 proofs are included here for optional context, with their dependencies stated.

## Run this folder independently
With Python 3, run `python E11/check.py`, then `python E11/independent_verify.py`. These unchanged original scripts write E11/results; if preserving supplied outputs, run on a copy. The packet-level reproduce_all.py automatically uses temporary copies. Both scripts use only the standard library. E11/PROOFS.md supplies the complete direct proof; results/main.json and independent.json contain exact certificates.

## Provenance and limits
Original plan, scripts, stdout/stderr, claim ledger and source-access records are retained. CURRENT_E11_FREEZE.json establishes the later frozen status; an older completed_pending_freeze statement in original documents is historical. Both samples inhabit the same diamond. No detector model, black-hole mechanism, general-spacetime uniqueness or literature novelty is established.
'''
(pack/'02_CONTINUUM_SAMPLE/00_READ_FIRST.md').write_text(cont)
(pack/'00_READ_FIRST.md').write_text('''# Two counterexamples: comparison first, independent sections next

Read 00_COMPARISON_AND_COUNTEREXAMPLES.pdf: comparison (pages 1-2), invariant map (page 3), finite-poset proof (pages 4-5), continuum proof (pages 6-7).

00_COMPARISON contains the exact scaling audit. 01_FINITE_POSET and 02_CONTINUUM_SAMPLE are independently readable and runnable: each begins with definitions, construction, certificates, invariants/distinguishing data, recovery limits and commands. Original source documents are retained, and new reader guides are labeled separately in provenance.

Run `python reproduce_all.py` from this directory to verify both witnesses, extract the invariant inventory and reproduce the scaling comparison in temporary copies. New outputs go to LOCAL_REPRODUCTION. Run `python verify_manifest.py` for file hashes. Python standard library only for verification.

04_PROVENANCE retains the preceding comparison ZIP unchanged, source-path hashes and packaging validation. No new search or attack; no canonical import. Audit10 v144 and E11 stay frozen.
''')
(pack/'reproduce_all.py').write_text('''from pathlib import Path
import tempfile,shutil,subprocess,sys,json
r=Path(__file__).resolve().parent;out=r/'LOCAL_REPRODUCTION';out.mkdir(exist_ok=True);runs=[]
with tempfile.TemporaryDirectory() as d:
 w=Path(d);source=w/'source';source.mkdir()
 for f in ['01_FINITE_POSET','02_CONTINUUM_SAMPLE']:shutil.copytree(r/f,source/f)
 shutil.copytree(r/'00_COMPARISON/AUDIT',w/'audit')
 scripts=[source/'01_FINITE_POSET/verify_counterexample.py',source/'01_FINITE_POSET/check_invariants.py',source/'02_CONTINUUM_SAMPLE/E11/check.py',source/'02_CONTINUUM_SAMPLE/E11/independent_verify.py',w/'audit/check.py',w/'audit/independent_verify.py']
 for i,p in enumerate(scripts):
  v=subprocess.run([sys.executable,str(p)],capture_output=True,text=True);assert v.returncode==0,(str(p),v.stderr)
  runs.append({'script':str(p.relative_to(w)),'exit_code':v.returncode,'stdout':v.stdout,'stderr':v.stderr})
  if i==1:assert v.stdout==(r/'01_FINITE_POSET/READER_INVARIANTS.json').read_text()
 for n in ['main.json','independent.json']:
  assert (source/'02_CONTINUUM_SAMPLE/E11/results'/n).read_bytes()==(r/'02_CONTINUUM_SAMPLE/E11/results'/n).read_bytes()
  assert (w/'audit/results'/n).read_bytes()==(r/'00_COMPARISON/AUDIT/results'/n).read_bytes()
(out/'validation.json').write_text(json.dumps({'kind':'new reader/package validation, not original discovery runs','runs':runs,'certificates_match':True},indent=2)+'\\n')
print('PASS: both witnesses, invariant inventory and scaling comparison reproduced exactly')
''')
(pack/'verify_manifest.py').write_text((prior/'verify_manifest.py').read_text())
pr=pack/'04_PROVENANCE';pr.mkdir(exist_ok=True)
shutil.copy2(root.parent/'output/Counterexample_Diagonal_Scaling_Comparison_QUARANTINED.zip',pr/'Previous_Comparison_Packet_UNCHANGED.zip')
(pr/'ORGANIZATION_SCOPE.md').write_text('This is a readability edition with new explanatory guides and invariant extraction, not a new research attack. Original files are copied byte-for-byte. The previous packet is preserved whole. All two-way import firewalls remain active. Original mathematical records, including corrections and historical statuses, are not rewritten. New scripts are reader/packaging programs, not reconstructed discovery code.\n')
(root/'content.json').write_text(json.dumps({'invariants':inv,'finite_guide':finite,'continuum_guide':cont},indent=2))
print(json.dumps({k:{'degrees':v['comparability_degree_multiset'],'pairs':v['strict_comparable_pair_count']} for k,v in inv.items()}))
