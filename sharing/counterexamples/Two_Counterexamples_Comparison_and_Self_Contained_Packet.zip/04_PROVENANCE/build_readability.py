from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess,sys
from reportlab.platypus import SimpleDocTemplate,Paragraph,Table,TableStyle
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader,PdfWriter
r=Path(__file__).resolve().parent;p=r/'packet';out=r.parent/'output'
pdfmetrics.registerFont(TTFont('DV','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));pdfmetrics.registerFont(TTFont('DVB','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
b=ParagraphStyle('b',fontName='DV',fontSize=9,leading=13,spaceAfter=9);t=ParagraphStyle('t',fontName='DVB',fontSize=20,leading=25,spaceAfter=16)
s=[Paragraph('Invariant and recovery map',t),Paragraph('Read this table as a selected certificate inventory, not a classification of everything recoverable from normalized data.',b)]
rows=[['Quantity','Finite-poset pair','Continuum-sample pair'],['Cardinality','16 versus 16','2 versus 2'],['Normalized overlaps','All 256 G entries agree','Both K=[[1,1/2],[1/2,1]]'],['Strict comparable pairs','65 versus 65 (agrees)','1 versus 0 (differs)'],['Nonisomorphism certificate','Downset sizes among upset-size-two elements: {5,8,9,10} versus {6,7,8,11}','Chain versus antichain; comparable-pair count differs'],['Sizes / volumes','Upset-size multisets agree; attached vectors differ','Future-volume multisets: {1/8,1/32} versus {1/16,1/16}'],['Comparability degrees','Multisets differ; exact lists below','Induced sampled-order degrees: {1,1} versus {0,0}'],['Attached-data recovery','G plus individually attached upset sizes d: x ≤ y iff Gxy² dx=dy','K plus individually attached future volumes a: x ≤ y iff Kxy² ax=ay']]
table=Table([[Paragraph(c,b) for c in row] for row in rows],colWidths=[112,208,208],hAlign='LEFT');table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e2e8f0')),('GRID',(0,0),(-1,-1),.4,colors.HexColor('#cbd5e1')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),5)]));s.append(table)
s.append(Paragraph('<br/><b>Exact finite-poset degree multisets</b><br/>P: [5,5,5,6,6,6,8,8,8,8,8,8,9,10,15,15]<br/>Q: [5,6,6,6,6,6,7,7,8,8,8,8,8,11,15,15]',b))
s.append(Paragraph('Order-isomorphism invariants must be distinguished from geometric data: future volumes and squared spacetime separations depend on the fixed continuum model. Equal normalized data do not imply equal orders. Diagonal scaling is equivalent to normalized equality and supplies no independent embedding claim.',b))
s.append(Paragraph('Packet map: pages 1-2 comparison; page 3 this map; pages 4-5 finite-poset construction; pages 6-7 continuum proof. Each numbered counterexample folder has its own reader guide, input, certificates, original evidence and independent run instructions.',b))
SimpleDocTemplate(str(r/'map.pdf'),pagesize=(612,792),leftMargin=42,rightMargin=42,topMargin=36,bottomMargin=36).build(s)
assert len(PdfReader(r/'map.pdf').pages)==1
w=PdfWriter()
for f,pages in [(out/'Counterexample_Diagonal_Scaling_Comparison.pdf',None),(r/'map.pdf',None),(p/'01_FINITE_POSET/Construction_and_Proof.pdf',None),(p/'02_CONTINUUM_SAMPLE/START_HERE_E11_FROZEN.pdf',[1,2])]:
 reader=PdfReader(f)
 for i in range(len(reader.pages)) if pages is None else pages:w.add_page(reader.pages[i])
w.add_outline_item('Comparison',0);w.add_outline_item('Invariant map',2);w.add_outline_item('Finite-poset counterexample',3);w.add_outline_item('Continuum counterexample',5)
final=out/'Two_Counterexamples_Comparison_and_Self_Contained_Guides.pdf';w.write(final);shutil.copy2(final,p/'00_COMPARISON_AND_COUNTEREXAMPLES.pdf')
subprocess.run([sys.executable,str(p/'reproduce_all.py')],check=True);shutil.copytree(p/'LOCAL_REPRODUCTION',p/'04_PROVENANCE/PACKAGING_VALIDATION',dirs_exist_ok=True);shutil.rmtree(p/'LOCAL_REPRODUCTION')
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
records=[]
for folder in ['01_FINITE_POSET','02_CONTINUUM_SAMPLE']:
 src=r.parent/'scaling_work/source'/folder
 for f in src.rglob('*'):
  if f.is_file():
   dst=p/folder/f.relative_to(src);assert f.read_bytes()==dst.read_bytes();records.append({'path':dst.relative_to(p).as_posix(),'source_path':str(f.relative_to(r.parent/'scaling_work/source')),'sha256':sha(f)})
(p/'04_PROVENANCE/EXACT_SOURCE_COPY_LEDGER.json').write_text(json.dumps(records,indent=2)+'\n')
for name in ['assemble.py','build_readability.py']:shutil.copy2(r/name,p/'04_PROVENANCE'/name)
(p/'SHA256SUMS.txt').write_text(''.join(sha(f)+'  '+f.relative_to(p).as_posix()+'\n' for f in sorted(p.rglob('*')) if f.is_file() and f.name!='SHA256SUMS.txt'))
zpath=out/'Two_Counterexamples_Comparison_and_Self_Contained_Packet.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(p.rglob('*')):
  if f.is_file():z.write(f,f.relative_to(p).as_posix())
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS.txt').decode().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h
print('PASS: seven-page PDF, exact original copies, reproduction and ZIP hashes',zpath.stat().st_size)
