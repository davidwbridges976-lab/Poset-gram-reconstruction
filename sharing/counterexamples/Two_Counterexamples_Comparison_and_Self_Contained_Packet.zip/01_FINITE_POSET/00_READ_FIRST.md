# Counterexample 1: finite-poset normalized overlaps

## Definitions and claim
For a finite poset, U(x)={y:x<=y}, d(x)=|U(x)|, H_xy=|U(x) intersect U(y)|, G_xy=H_xy/sqrt(d(x)d(y)). Self-membership is included. Two nonisomorphic 16-element orders have exactly equal G under the supplied labels, disproving universal G-only recovery.

## Construction and proof
Construction_and_Proof.pdf gives both orders and a complete block proof of equal G. core/counterexample_input.json contains their full 16x16 zeta matrices. Two Boolean sectors use phi=[0,1,1,3,1,3,5,7]. P uses inclusion and cross relation phi(X) subset Y; Q uses reverse inclusion and cross relation Y subset phi(X); no W-to-E relations.

## Invariants: what agrees and what differs
Both have 16 elements and 65 strict comparable pairs. The normalized matrix agrees at every labeled pair. The upset-size multisets agree (although attached vectors differ). The joint upset/downset information differs: among upset-size-two elements, P has downset sizes [5,8,9,10], Q has [6,7,8,11]. This is an order-isomorphism invariant and certifies nonisomorphism.
Comparability degree counts distinct comparable other elements, so c(x)=|U(x)|+|downset(x)|-2. Their degree multisets differ; see READER_INVARIANTS.json for exact vectors and multisets. This witness therefore does not refute G plus unordered comparability-degree-multiset recovery.

## What restores recovery
G plus individually attached upset sizes recovers the order: x<=y iff G_xy^2 d_x=d_y. Proof: this equality says H_xy^2=d_y^2, so H_xy=d_y; therefore U(y) subset U(x), which is equivalent to x<=y. An unordered size multiset is not the same as individually attached sizes. Comparability degrees are also different quantities.

## Run this folder independently
With Python 3, run `python verify_counterexample.py` to check poset axioms, all 256 exact squared Gram entries and nonisomorphism. Run `python check_invariants.py` to display the inventory. Both need only the standard library and the files in this folder. The original reader verifier is retained unchanged; check_invariants.py is a new reader extraction.

## Provenance and limits
Original_Reader_Run.json retains original verification plus related historical checks; the extra scripts named in that historical record are not needed for this witness. The construction PDF records a corrected historical element label. No 16-element minimality or literature novelty claim is made. Audit10 remains frozen at v144; this organization does not promote new mathematics.
