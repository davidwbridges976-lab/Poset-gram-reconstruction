"""New reader certificate extraction, not a discovery or general search."""
from pathlib import Path
import json
r=Path(__file__).resolve().parent
x=json.loads((r/'core/counterexample_input.json').read_text());out={}
for name,key in [('P','source_zeta'),('Q','candidate_zeta')]:
 Z=x[key];n=len(Z);u=list(map(sum,Z));d=[sum(Z[j][i] for j in range(n)) for i in range(n)]
 out[name]={'element_count':n,'upset_sizes':u,'downset_sizes':d,'upset_size_multiset':sorted(u),'downset_size_multiset':sorted(d),'upset_two_downset_sizes':sorted(d[i] for i in range(n) if u[i]==2),'comparability_degree_multiset':sorted(u[i]+d[i]-2 for i in range(n)),'strict_comparable_pair_count':sum(u)-n}
assert out['P']['upset_two_downset_sizes']==[5,8,9,10]
assert out['Q']['upset_two_downset_sizes']==[6,7,8,11]
assert out['P']['comparability_degree_multiset']!=out['Q']['comparability_degree_multiset']
print(json.dumps(out,indent=2))
