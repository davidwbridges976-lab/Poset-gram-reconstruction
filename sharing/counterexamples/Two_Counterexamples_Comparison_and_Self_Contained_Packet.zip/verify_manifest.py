from pathlib import Path
import hashlib
r=Path(__file__).resolve().parent
for line in (r/'SHA256SUMS.txt').read_text().splitlines():
 h,n=line.split('  ',1);assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
print('PASS: packet hashes verified')
