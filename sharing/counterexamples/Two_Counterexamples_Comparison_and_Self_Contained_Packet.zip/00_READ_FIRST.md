# Two counterexamples: comparison first, independent sections next

Read 00_COMPARISON_AND_COUNTEREXAMPLES.pdf: comparison (pages 1-2), invariant map (page 3), finite-poset proof (pages 4-5), continuum proof (pages 6-7).

00_COMPARISON contains the exact scaling audit. 01_FINITE_POSET and 02_CONTINUUM_SAMPLE are independently readable and runnable: each begins with definitions, construction, certificates, invariants/distinguishing data, recovery limits and commands. Original source documents are retained, and new reader guides are labeled separately in provenance.

Run `python reproduce_all.py` from this directory to verify both witnesses, extract the invariant inventory and reproduce the scaling comparison in temporary copies. New outputs go to LOCAL_REPRODUCTION. Run `python verify_manifest.py` for file hashes. Python standard library only for verification.

04_PROVENANCE retains the preceding comparison ZIP unchanged, source-path hashes and packaging validation. No new search or attack; no canonical import. Audit10 v144 and E11 stay frozen.
