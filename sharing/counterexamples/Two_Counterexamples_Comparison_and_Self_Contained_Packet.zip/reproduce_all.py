from pathlib import Path
import tempfile,shutil,subprocess,sys,json
r=Path(__file__).resolve().parent;out=r/'LOCAL_REPRODUCTION';out.mkdir(exist_ok=True);runs=[]
with tempfile.TemporaryDirectory() as d:
 w=Path(d);source=w/'source';source.mkdir()
 for f in ['01_FINITE_POSET','02_CONTINUUM_SAMPLE']:shutil.copytree(r/f,source/f)
 shutil.copytree(r/'00_COMPARISON/AUDIT',w/'audit')
 scripts=[source/'01_FINITE_POSET/verify_counterexample.py',source/'01_FINITE_POSET/check_invariants.py',source/'02_CONTINUUM_SAMPLE/E11/check.py',source/'02_CONTINUUM_SAMPLE/E11/independent_verify.py',w/'audit/check.py',w/'audit/independent_verify.py']
 for i,p in enumerate(scripts):
  v=subprocess.run([sys.executable,str(p)],capture_output=True,text=True);assert v.returncode==0,(str(p),v.stderr)
  runs.append({'script':str(p.relative_to(w)),'exit_code':v.returncode,'stdout':v.stdout,'stderr':v.stderr})
  if i==1:assert v.stdout==(r/'01_FINITE_POSET/READER_INVARIANTS.json').read_text()
 for n in ['main.json','independent.json']:
  assert (source/'02_CONTINUUM_SAMPLE/E11/results'/n).read_bytes()==(r/'02_CONTINUUM_SAMPLE/E11/results'/n).read_bytes()
  assert (w/'audit/results'/n).read_bytes()==(r/'00_COMPARISON/AUDIT/results'/n).read_bytes()
(out/'validation.json').write_text(json.dumps({'kind':'new reader/package validation, not original discovery runs','runs':runs,'certificates_match':True},indent=2)+'\n')
print('PASS: both witnesses, invariant inventory and scaling comparison reproduced exactly')
