# Diagonal-scaling comparison of two exact counterexamples
Completed comparison audit | 5 October 2026 | quarantined reference branch

## Verdict
PASS: both witnesses exhibit positive diagonal congruence of their unnormalized overlap matrices. The independent reconstruction agrees exactly. This is the common algebraic normalization mechanism, not a demonstrated embedding, common geometric realization or physical mechanism.

## General lemma and its limitation
Let H and J be symmetric matrices with strictly positive diagonal entries. Define N(H)_ij=H_ij/sqrt(H_ii H_jj). Then N(H)=N(J) if and only if J=S H S, where the positive diagonal matrix has S_ii=sqrt(J_ii/H_ii).
Proof: equality of normalized entries rearranges to J_ij=sqrt(J_ii/H_ii) H_ij sqrt(J_jj/H_jj). Conversely diagonal scaling cancels under normalization. The scales are uniquely determined for a given pair by the diagonals. No invertibility or positive-definiteness assumption is needed for this identity.
Therefore this comparison is not an independent confirmation of a deeper connection: it is an exact characterization of the normalized equality already present. Arbitrary scaling need not yield another valid poset or a realizable family of continuum futures. Each witness's separate construction supplies that realizability.

## Finite-poset witness
Recompute H=Z_P Z_P^T and J=Z_Q Z_Q^T from the retained 16-label input. For sector label i, e_i=2^(3-popcount(i mod 8)). S_ii=sqrt(8)/e_i. All 256 entries obey J_ij=S_ii H_ij S_jj. The scales squared on each sector in bitmask order are [1/8,1/2,1/2,2,1/2,2,2,8]. The source construction remains a nonisomorphic pair, certified by differing downset-size multisets among upset-size-two elements.

## Continuum witness
In the same fixed R=(0,1)^2, the full future-intersection matrices are:
H_P=[[1/8,1/32],[1/32,1/32]],
H_Q=[[1/16,1/32],[1/32,1/16]].
S=diag(1/sqrt(2),sqrt(2)) gives H_Q=S H_P S. Both normalize to [[1,1/2],[1/2,1]]. The chain and antichain remain nonisomorphic. The offdiagonal is unchanged because the two scale factors multiply to one; the diagonals change.

## Exact execution
PLAN_BEFORE_EXECUTION.md was written before checks. check.py recomputed the poset matrices from retained inputs and the continuum intersections from null coordinates. independent_verify.py constructed the poset futures directly from subset rules and the continuum futures from separately specified (t,z) coordinates. Each ran once; all assertions passed. Rational squares plus nonnegative entries certify the positive-root identities without floating-point tolerances. All scripts, exact matrices, stdout/stderr and run ledger are retained. No search, variant or solver was used.

## Sharing statement and limits
A precise description of E11 is: two two-event samples in one fixed open 1+1 Minkowski diamond have identical normalized continuum future overlaps but nonisomorphic induced causal orders. This does not say that counting upsets in those two finite sampled posets gives the same G. Individually attached future volumes restore the specified causal order; full-domain E10 has different hypotheses. No literature novelty audit was performed here. No black-hole dynamics, detector implementation or physical information paradox follows from this comparison.

## Firewalls and next decision
Audit10 v144, E11 and the original two-counterexample sharing packet remain unchanged. This is a separate completed comparison, not E12 or a canonical import. Full branch history is retained in the parent checkpoint; this packet preserves the compact source packet byte-for-byte. Import in either direction requires a separate source/hypothesis/observation-map/proof/destination audit.
Next possible target, NOT RUN: test whether a representation of the 16-element witness by continuum future regions exists in a precisely fixed geometry. Its hypotheses must be chosen before execution, and discussed first; the present scaling result does not imply it. Stop here pending the user's next decision.
