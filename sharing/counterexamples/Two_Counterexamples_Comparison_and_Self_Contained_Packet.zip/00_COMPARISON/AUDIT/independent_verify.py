from pathlib import Path
from fractions import Fraction as R
import json
root=Path(__file__).resolve().parent
# Independently construct orders from the subset rules, not the supplied matrices.
phi=[0,1,1,3,1,3,5,7]
sub=lambda a,b:a&b==a
labels=[(s,a) for s in range(2) for a in range(8)]
def related(x,y,reverse):
 s,a=x;t,b=y
 if s==t:return sub(b,a) if reverse else sub(a,b)
 if s==0 and t==1:return sub(b,phi[a]) if reverse else sub(phi[a],b)
 return False
futures=[[{y for y in labels if related(x,y,r)} for x in labels] for r in [False,True]]
HP,HQ=[[[R(len(a&b)) for b in f] for a in f] for f in futures]
# Independent Minkowski coordinates; future side lengths in null directions.
events=[[(R(1,2),R(0)),(R(3,4),R(0))],[(R(5,8),-R(1,8)),(R(5,8),R(1,8))]]
CC=[]
for group in events:
 sides=[(1-t-z,1-t+z) for t,z in group]
 CC.append([[min(a[0],b[0])*min(a[1],b[1])/2 for b in sides] for a in sides])
result={}
for name,H,J in [('poset',HP,HQ),('continuum',*CC)]:
 n=len(H);scale=[J[i][i]/H[i][i] for i in range(n)]
 for i in range(n):
  for j in range(n):
   assert J[i][j]**2/(J[i][i]*J[j][j])==H[i][j]**2/(H[i][i]*H[j][j])
 result[name]={'H':[[str(v) for v in row] for row in H],'H_prime':[[str(v) for v in row] for row in J],'S_squared':list(map(str,scale)),'entries_checked':n*n,'positive_diagonal_congruence':True}
main=json.loads((root/'results/main.json').read_text())
assert all(result[k]==main[k] for k in result)
result['main_certificates_match']=True
(root/'results/independent.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS: independent subset and Minkowski constructions match both full certificates')
