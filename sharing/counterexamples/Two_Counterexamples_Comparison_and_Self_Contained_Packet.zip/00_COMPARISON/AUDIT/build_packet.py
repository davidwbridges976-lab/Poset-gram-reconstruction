from pathlib import Path
import hashlib,json,zipfile,shutil
from reportlab.platypus import SimpleDocTemplate,Paragraph,PageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
r=Path(__file__).resolve().parent;out=r.parent.parent/'output';out.mkdir(exist_ok=True)
pdfmetrics.registerFont(TTFont('DV','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));pdfmetrics.registerFont(TTFont('DVB','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
b=ParagraphStyle('b',fontName='DV',fontSize=10,leading=15,spaceAfter=10);h=ParagraphStyle('h',fontName='DVB',fontSize=13,leading=18,spaceBefore=8,spaceAfter=8);t=ParagraphStyle('t',fontName='DVB',fontSize=21,leading=26,spaceAfter=16)
s=[]
def p(x):s.append(Paragraph(x,b))
def head(x):s.append(Paragraph(x,h))
s.append(Paragraph('What the two counterexamples share',t));p('Exact diagonal-scaling comparison • 5 October 2026 • quarantined audit')
head('Result: PASS, with a precise limitation');p('Both unnormalized overlap matrices are related by positive diagonal scaling. Main and independent exact checks agree. This establishes the shared algebraic pattern; it does not establish a geometric embedding or physical connection.')
head('The general identity');p('For symmetric H and J with positive diagonals, define N(H)<sub>ij</sub>=H<sub>ij</sub>/√(H<sub>ii</sub>H<sub>jj</sub>). Then N(H)=N(J) exactly when J=S H S, with S<sub>ii</sub>=√(J<sub>ii</sub>/H<sub>ii</sub>)>0. Rearranging the normalized equality proves the forward direction; cancellation proves the reverse.')
p('Consequently diagonal congruence is an algebraic restatement of equal normalized data. A pass here is not independent evidence of a deeper connection. The nontrivial additional fact in each original witness is that both overlap matrices arise from valid, nonisomorphic orders in their respective models.')
head('Finite-poset witness: 16 labels');p('H=Z<sub>P</sub>Z<sub>P</sub><super>T</super>, J=Z<sub>Q</sub>Z<sub>Q</sub><super>T</super>. On either Boolean sector, e<sub>i</sub>=2<super>3−|X<sub>i</sub>|</super> and S<sub>ii</sub>=√8/e<sub>i</sub>. All 256 entries satisfy J=S H S. An independent program reconstructs futures from subset rules instead of reading the zeta matrices.')
head('Continuum witness: two events');p('H<sub>P</sub>=[[1/8,1/32],[1/32,1/32]].<br/>H<sub>Q</sub>=[[1/16,1/32],[1/32,1/16]].<br/>S=diag(1/√2,√2), so H<sub>Q</sub>=S H<sub>P</sub> S.<br/>Both normalize to [[1,1/2],[1/2,1]]. The offdiagonal stays fixed because the scales multiply to one; the diagonals change.')
s.append(PageBreak());s.append(Paragraph('Evidence, scope and sharing',t));head('What the second counterexample says');p('Two two-event samples in the same fixed open 1+1 Minkowski diamond have equal normalized overlaps of their full continuum future regions. One sample is a chain; the other is an antichain. The samples are therefore nonisomorphic as induced orders.')
p('This uses continuum volumes, not counts of successors among the two sampled events. Individually attached future volumes distinguish the samples and restore the stated causal order. The full-domain E10 result uses all interior events and is not contradicted.')
head('Reproduction and provenance');p('The predeclared plan, two executed Python scripts, exact matrices, output logs and run ledger are in AUDIT/. The source sharing ZIP is included unchanged in SOURCE/. Verification uses only the Python standard library and rational arithmetic; there was no floating-point approximation, variant search or solver.')
p('Unzip and run <b>python reproduce_comparison.py</b>. New output goes to LOCAL_REPRODUCTION and is compared with both retained JSON certificates. Run <b>python verify_manifest.py</b> to check every packaged file hash. These are reader reruns, separate from the original audit executions.')
head('Firewalls');p('Audit10 v144 and E11 remain frozen. The original sharing packet is preserved byte-for-byte. This comparison is not a canonical import or an E12 checkpoint. Any transfer requires a separate scoped audit of hypotheses, observation maps, proof and destination.')
head('What remains open');p('No realization of the 16-element pair by continuum futures has been demonstrated here. No literature novelty claim or black-hole mechanism follows. A geometric realization question would be a separate next target, with its geometry fixed before testing; no such test was run.')
p('For Saturday’s planned post, the strongest supported lead is the explicit chain-versus-antichain continuum counterexample itself. The scaling comparison is explanatory context, not a claim of a new physical discovery.')
def footer(c,d):c.setFont('DV',8);c.drawString(42,25,'Diagonal-scaling comparison | Audit10 and E11 unchanged');c.drawRightString(570,25,str(d.page))
SimpleDocTemplate(str(out/'Counterexample_Diagonal_Scaling_Comparison.pdf'),pagesize=(612,792),leftMargin=42,rightMargin=42,topMargin=42,bottomMargin=44).build(s,onFirstPage=footer,onLaterPages=footer)
pack=r.parent/'package';pack.mkdir(exist_ok=True);shutil.copytree(r,pack/'AUDIT',dirs_exist_ok=True);(pack/'SOURCE').mkdir(exist_ok=True)
source=r.parent.parent/'scaling_inputs/Two_Counterexamples_Reproducible_Packet.zip';shutil.copy2(source,pack/'SOURCE'/source.name)
shutil.copy2(out/'Counterexample_Diagonal_Scaling_Comparison.pdf',pack/'00_COMPARISON.pdf')
(pack/'00_READ_FIRST.md').write_text('''# Exact diagonal-scaling comparison
Read 00_COMPARISON.pdf (two pages), then AUDIT/REPORT.md. Both exact checks passed. Positive diagonal congruence is equivalent to normalized equality; it is not independent evidence of a geometric or physical mapping.

SOURCE/ contains the unchanged original two-counterexample packet. AUDIT/ contains the predeclared plan, executed programs, exact results, full proof, run ledger and roadmap. No parent checkpoint was modified and no canonical import is approved.

With Python 3, run `python reproduce_comparison.py` for isolated reader reproduction, or `python verify_manifest.py` to verify hashes. No dependencies or network are needed for verification. The PDF authoring script needs ReportLab only if you choose to rebuild the presentation.
''')
(pack/'reproduce_comparison.py').write_text('''from pathlib import Path
import zipfile,tempfile,subprocess,sys,shutil
root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as d:
 w=Path(d)
 with zipfile.ZipFile(root/'SOURCE/Two_Counterexamples_Reproducible_Packet.zip') as z:z.extractall(w/'source')
 shutil.copytree(root/'AUDIT',w/'audit')
 for name in ['check.py','independent_verify.py']:
  subprocess.run([sys.executable,str(w/'audit'/name)],check=True)
 for name in ['main.json','independent.json']:
  assert (w/'audit/results'/name).read_bytes()==(root/'AUDIT/results'/name).read_bytes()
 out=root/'LOCAL_REPRODUCTION';out.mkdir(exist_ok=True)
 for name in ['main.json','independent.json']:shutil.copy2(w/'audit/results'/name,out/name)
print('PASS: both comparison certificates reproduced exactly')
''')
(pack/'verify_manifest.py').write_text('''from pathlib import Path
import hashlib
r=Path(__file__).resolve().parent
for line in (r/'SHA256SUMS.txt').read_text().splitlines():
 h,n=line.split('  ',1);assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
print('PASS: packet hashes verified')
''')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(pack/'AUDIT/PROVENANCE.json').write_text(json.dumps({'source_archive':source.name,'source_sha256':sha(source),'status':'comparison completed; parent checkpoints unchanged','canonical_import':False,'failures_or_corrections':[],'runs':'one main and one independent original execution; reader reruns are separate'},indent=2)+'\n')
(pack/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.relative_to(pack).as_posix()+'\n' for p in sorted(pack.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt'))
with zipfile.ZipFile(out/'Counterexample_Diagonal_Scaling_Comparison_QUARANTINED.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(pack.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(pack).as_posix())
print('Built comparison PDF and quarantined evidence ZIP')
