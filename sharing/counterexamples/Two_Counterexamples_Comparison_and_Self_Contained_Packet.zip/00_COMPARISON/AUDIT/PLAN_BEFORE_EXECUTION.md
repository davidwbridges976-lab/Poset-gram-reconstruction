# Diagonal-scaling comparison - predeclared audit
Target: confirm the explicit positive diagonal congruence for the two retained witnesses, not find a new collision or physical map.
Inputs: extracted, manifest-verified Two_Counterexamples_Reproducible_Packet.zip, finite-poset exact zeta matrices and E11 exact coordinates/certificates.
General lemma: for symmetric H,H' with strictly positive diagonals, N(H)=N(H') iff H'=S H S with S_ii=sqrt(H'_ii/H_ii)>0. This is algebraic equivalence, not independent evidence beyond normalized equality. Poset/geometry realization is an additional constraint.
Checks: recompute unnormalized matrices from source inputs; verify expected squared scales; verify squared congruence exactly with nonnegative entries; independently construct the Boolean-sector pair and the continuum futures via (t,z); compare full certificates.
Expected poset scales squared: 8/e_i^2 where e_i=2^(3-popcount(i mod 8)). Expected continuum scales squared: (1/2,2). Record PASS/FAIL without changing input or trying variants.
No canonical import, E12 designation, embedding search, variant, literature novelty audit or physical conclusion. Audit10 v144 and E11 remain frozen. One main check and one independent check; retain scripts, outputs and any corrections. After this result build and verify this audit packet before further work.
