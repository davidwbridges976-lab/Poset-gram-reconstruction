from pathlib import Path
from fractions import Fraction as F
import json
root=Path(__file__).resolve().parent;src=root.parent/'source'
x=json.loads((src/'01_FINITE_POSET/core/counterexample_input.json').read_text())
def gram(M):return [[F(sum(a*b for a,b in zip(r,s))) for s in M] for r in M]
def cert(H,J):
 n=len(H);s=[J[i][i]/H[i][i] for i in range(n)]
 assert all(t>0 for t in s)
 assert all(H[i][j]>=0 and J[i][j]>=0 and J[i][j]**2==s[i]*s[j]*H[i][j]**2 for i in range(n) for j in range(n))
 return {'H':[[str(t) for t in r] for r in H],'H_prime':[[str(t) for t in r] for r in J],'S_squared':list(map(str,s)),'entries_checked':n*n,'positive_diagonal_congruence':True}
a=cert(gram(x['source_zeta']),gram(x['candidate_zeta']))
assert a['S_squared']==[str(F(8,2**(2*(3-(i%8).bit_count())))) for i in range(16)]
pts={'P':[(F(1,2),F(1,2)),(F(3,4),F(3,4))],'Q':[(F(1,2),F(3,4)),(F(3,4),F(1,2))]}
def regions(p):return [[(1-max(u,v))*(1-max(s,t))/2 for v,t in p] for u,s in p]
b=cert(regions(pts['P']),regions(pts['Q']));assert b['S_squared']==['1/2','2']
result={'poset':a,'continuum':b,'interpretation':'algebraic equivalence of normalized equality, not an independently demonstrated embedding or physical connection'}
(root/'results/main.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS: 256 poset and 4 continuum exact diagonal-congruence entries')
