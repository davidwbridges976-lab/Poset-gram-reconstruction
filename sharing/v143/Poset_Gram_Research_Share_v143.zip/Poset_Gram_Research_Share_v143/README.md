# Normalized upset overlaps: a reproducible reconstruction investigation

David Bridges | Sharing snapshot, 3 October 2026 | Based on frozen v143

**Start with START_HERE.pdf (3 pages).** This packet includes an explicit counterexample, exact verification code, and recent scoped results. No novelty or priority claim is made.

For a finite poset, let U_x contain x and everything above it. We study the matrix

    G(x,y) = |U_x intersect U_y| / sqrt(|U_x| |U_y|).

**Known failure:** G alone does not determine every finite poset up to isomorphism. The included 16-label orders have exactly the same G and are nonisomorphic. Their comparability-degree multisets differ. Both G-only ambiguity and the unequal degree data are reproduced here.

**Open question in this investigation:** does G together with the unordered comparability-degree multiset determine every finite poset? This packet does not establish that it does, or certify that the question is open in the literature.

**Recent scoped results:** with positive-entry G, original alternative-anchor upset size eight, and endpoint saturation, degree matching forces isomorphism for one or two base labels, and for the three-base order with two incomparable lower labels and one greatest. The two-base class has 66 map representations, 30 degree matches; the latter three-base class has 4,356 ordered map pairs, 1,068 degree matches. Every matched pair is isomorphic. These are complete specified classes, not exhaustive populations of all 16- or 24-element posets. The three-chain base and broader classes remain unresolved.

## Reproduce

Python 3.10+; standard library only. Extract the ZIP, open a terminal in this folder, then run:

    python3 reproduce.py

No solver, installation or network is needed. The runner checks the counterexample, its entire positive-entry Gram fiber, the scale audit, all 4,356 recent class representations and an independent canonical-form calculation. It regenerates complete gzip ledgers and explicit isomorphism certificates. Run normally, without Python's -O option: verification uses assertions. REPRODUCTION_RUN.json records this edition's actual execution.

## Reading map

- START_HERE.pdf: the question, counterexample and recent scoped result.
- proofs/README.md: optional proof/dependency map; source proof reports and frozen scope reviews.
- code/: exact core sources and a documented portable adaptation of the recent verifier.
- provenance/: original verifier, original outputs, source hashes and adaptation notes.
- SHA256SUMS.txt: integrity inventory for the distributed snapshot; rerunning changes execution outputs.

Repository for further context: https://github.com/davidwbridges976-lab/Poset-gram-reconstruction

This sharing edition is independently runnable. The repository link is optional context; no repository update or Reddit post was made when creating it. The historical research archive is outside this concise edition.
