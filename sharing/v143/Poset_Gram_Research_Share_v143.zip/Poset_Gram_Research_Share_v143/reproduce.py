"""Standalone reader runner, newly executed for this sharing edition."""
from pathlib import Path
import subprocess,sys,json,time
root=Path(__file__).resolve().parent
start=time.perf_counter();records=[]
for name in ['code/core/run_all.py','code/three_base/verify.py','code/three_base/independent_verify.py']:
 result=subprocess.run([sys.executable,str(root/name)],capture_output=True,text=True)
 records.append({'script':name,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
 print(result.stdout.strip())
 if result.returncode:
  print(result.stderr,file=sys.stderr);raise SystemExit(result.returncode)
# Compare all mathematical/status fields against the frozen original outputs; timings may vary.
for name in ['exact_output.json','independent_output.json']:
 expected=json.loads((root/'provenance/original_v143'/name).read_text())
 actual=json.loads((root/'code/three_base/results'/name).read_text())
 assert {k:v for k,v in actual.items() if k!='seconds'}=={k:v for k,v in expected.items() if k!='seconds'}
(root/'REPRODUCTION_RUN.json').write_text(json.dumps({'all_passed':True,'runs':records,'seconds':time.perf_counter()-start},indent=2)+'\n')
print('PASS: core counterexample and fiber; all 4,356 three-base pairs; independent degree and isomorphism audit.')
