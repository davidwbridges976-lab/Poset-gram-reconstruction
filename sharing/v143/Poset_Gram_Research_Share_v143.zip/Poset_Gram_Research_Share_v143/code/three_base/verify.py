from pathlib import Path
from itertools import permutations,product
from collections import Counter
import json,zipfile,hashlib,gzip,time
# Reader adaptation: local inputs replace the parent-archive integrity/materialization preamble.
R=Path(__file__).resolve().parent/'results';R.mkdir(exist_ok=True)
data=Path(__file__).resolve().parent/'data'
start=time.perf_counter()
raw=(data/'v142_map_certificates.json').read_bytes();(R/'v142_map_certificates.json').write_bytes(raw)
oldraw=(data/'original_counterexample_input.json').read_bytes();(R/'original_counterexample_input.json').write_bytes(oldraw)
maps=[x['phi'] for x in json.loads(raw)];assert len(maps)==66 and len({tuple(x) for x in maps})==66
# Independent map reconstruction from rank choices.
ind=[]
for a in product([1,2,4],repeat=3):
 for c in product([3,5,6],repeat=3):
  f=[0,a[0],a[1],c[0],a[2],c[1],c[2],7]
  if all(f[x]&f[y]==f[x] for x in range(8) for y in range(8) if x&y==x):ind.append(f)
assert sorted(ind)==sorted(maps)
U=[sum(1<<y for y in range(8) if x&y==x) for x in range(8)]
D=[sum(1<<y for y in range(8) if y&x==y) for x in range(8)]
perms=list(permutations(range(3)))
perm_maps=[[sum(1<<p[k] for k in range(3) if x&(1<<k)) for x in range(8)] for p in perms]
def orders(f,g):
 P=[U[x]|(U[f[x]]<<16) for x in range(8)]+[(U[x]<<8)|(U[g[x]]<<16) for x in range(8)]+[U[x]<<16 for x in range(8)]
 Q=[D[x]|(D[f[x]]<<16) for x in range(8)]+[(D[x]<<8)|(D[g[x]]<<16) for x in range(8)]+[D[x]<<16 for x in range(8)]
 return P,Q
def poset(Z):
 n=len(Z)
 return all((Z[i]>>i)&1 for i in range(n)) and all(i==j or not((Z[i]>>j)&1 and (Z[j]>>i)&1) for i in range(n) for j in range(n)) and all(not((Z[i]>>j)&1) or Z[j]&Z[i]==Z[j] for i in range(n) for j in range(n))
def degrees(Z):return [Z[i].bit_count()+sum((row>>i)&1 for row in Z)-2 for i in range(len(Z))]
def exact_gram(P,Q):
 n=len(P);dp=[x.bit_count() for x in P];dq=[x.bit_count() for x in Q]
 return all((P[i]&P[j]).bit_count()**2*dq[i]*dq[j]==(Q[i]&Q[j]).bit_count()**2*dp[i]*dp[j] for i in range(n) for j in range(i,n))
# compat[(source map,target map,upper permutation)] retains every admissible lower permutation.
compat={}
for i,f in enumerate(maps):
 for j,g in enumerate(maps):
  for k,pm in enumerate(perm_maps):
   opts=[l for l,lm in enumerate(perm_maps) if all(pm[f[x]]==(7^g[7^lm[x]]) for x in range(8))]
   if opts:compat[i,j,k]=opts
(R/'cube_map_compatibility.json').write_text(json.dumps([{'source':i,'target':j,'upper_permutation':k,'lower_permutations':v} for (i,j,k),v in compat.items()],indent=2)+'\n')
def iso(i,j):
 for k,pm in enumerate(perm_maps):
  for swap in [False,True]:
   targets=[j,i] if swap else [i,j]
   choices=[compat.get((s,t,k),[]) for s,t in zip([i,j],targets)]
   if not all(choices):continue
   image=[]
   for fiber,l in enumerate([v[0] for v in choices]):
    target=(1-fiber) if swap else fiber;lm=perm_maps[l];image.extend([8*target+(7^lm[x]) for x in range(8)])
   image.extend([16+(7^pm[y]) for y in range(8)]);return image
 return None
ledger=[];matchcount=isocount=badcount=0;first=None
for i,f in enumerate(maps):
 for j,g in enumerate(maps):
  P,Q=orders(f,g);assert poset(P) and poset(Q) and exact_gram(P,Q)
  gp,gq=degrees(P),degrees(Q);degree_match=sorted(gp)==sorted(gq)
  # Intrinsic partition: two minimal labels; upper fiber has both as predecessors.
  for Z in [P,Q]:
   mins=[a for a in range(24) if sum((row>>a)&1 for row in Z)==1];assert len(mins)==2
   assert all(sum((Z[a]>>x)&1 for a in mins)==(2 if x>=16 else 1) for x in range(24))
  image=iso(i,j)
  if image is not None:
   assert degree_match and len(set(image))==24 and all(((P[a]>>b)&1)==((Q[image[a]]>>image[b])&1) for a in range(24) for b in range(24))
  matchcount+=degree_match;isocount+=image is not None;bad=degree_match and image is None;badcount+=bad
  record={'map_indices':[i,j],'degree_multiset_P':sorted(gp),'degree_multiset_Q':sorted(gq),'degree_match':degree_match,'isomorphic':image is not None,'isomorphism':image}
  ledger.append(record)
  if bad and first is None:first={'map_indices':[i,j],'phi':f,'psi':g,'P_rows':P,'Q_rows':Q,'degrees_P':sorted(gp),'degrees_Q':sorted(gq),'all_432_structural_isomorphisms_rejected':True,'n':24}
with gzip.open(R/'complete_pair_ledger.jsonl.gz','wt') as z:
 for record in ledger:z.write(json.dumps(record)+'\n')
if first is not None:(R/'first_degree_matched_nonisomorphic_pair.json').write_text(json.dumps(first,indent=2)+'\n')
# Original 16-label matrices remain exactly retained and valid; do not reinterpret them.
x=json.loads(oldraw);P=[sum(v<<j for j,v in enumerate(row)) for row in x['source_zeta']];Q=[sum(v<<j for j,v in enumerate(row)) for row in x['candidate_zeta']];assert poset(P) and poset(Q) and exact_gram(P,Q) and sorted(degrees(P))!=sorted(degrees(Q))
# Cube automorphism pairs are positive degree/isomorphism controls in this family.
auto=[i for i,f in enumerate(maps) if len(set(f))==8];assert len(auto)==6
assert all(ledger[66*i+j]['degree_match'] and ledger[66*i+j]['isomorphic'] for i in auto for j in auto)
out={'all_checks_passed':True,'map_count':66,'ordered_pairs_checked':len(ledger),'degree_matching_pairs':matchcount,'isomorphic_pairs':isocount,'degree_matching_nonisomorphic_pairs':badcount,'original_collision_preserved':True,'positive_automorphism_pair_controls':36,'full_n24_ambient_population_exhaustive':False,'three_chain_base':'NOT TESTED','first_witness_map_indices':first['map_indices'] if first else None,'seconds':time.perf_counter()-start}
(R/'exact_output.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
