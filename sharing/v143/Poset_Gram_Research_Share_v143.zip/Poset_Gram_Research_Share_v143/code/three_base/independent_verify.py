from pathlib import Path
from itertools import permutations
from collections import Counter
import json,gzip,time
# Reader adaptation: use the local reader-result directory.
R=Path(__file__).resolve().parent/'results';start=time.perf_counter()
old=json.loads((R/'v142_map_certificates.json').read_text());maps=[x['phi'] for x in old];indices={tuple(f):i for i,f in enumerate(maps)}
perms=[[sum(1<<p[k] for k in range(3) if x&(1<<k)) for x in range(8)] for p in permutations(range(3))]
# Domain-normalize each map independently for each COMMON codomain permutation.
normal=[[min(tuple(out[f[dom[x]]] for x in range(8)) for dom in perms) for out in perms] for f in maps]
dual=[indices[tuple(7^f[7^x] for x in range(8))] for f in maps]
def canonical(i,j):return min(tuple(sorted((normal[i][k],normal[j][k]))) for k in range(6))
common_lower=[6,6,6,8,8,8,8,15]*2
count=degree_count=iso_count=compensated=0;cert=[]
with gzip.open(R/'complete_pair_ledger.jsonl.gz','rt') as z:
 for line in z:
  case=json.loads(line);i,j=case['map_indices'];f,g=maps[i],maps[j]
  N=[sum(h[x]==a for h in [f,g] for x in [1,2,4]) for a in [1,2,4]]
  M=[sum(h[x]==(7^a) for h in [f,g] for x in [3,5,6]) for a in [1,2,4]]
  dp=sorted(common_lower+[9,23]+[6+n for n in N]+[12-n+m for n,m in zip(N,M)])
  dq=sorted(common_lower+[9,23]+[6+m for m in M]+[12+n-m for n,m in zip(N,M)])
  assert dp==case['degree_multiset_P'] and dq==case['degree_multiset_Q']
  cp=canonical(i,j);cq=canonical(dual[i],dual[j]);iso=cp==cq
  assert iso==case['isomorphic'] and (dp==dq)==case['degree_match']
  count+=1;degree_count+=dp==dq;iso_count+=iso
  compensated+=(dp==dq and (not old[i]['degree_match'] or not old[j]['degree_match']))
  cert.append({'map_indices':[i,j],'aggregate_atom_counts':N,'aggregate_opposite_coatom_counts':M,'canonical_P':cp,'canonical_complemented_Q':cq,'canonical_equal':iso})
assert count==4356
with gzip.open(R/'independent_canonical_and_degree_certificates.jsonl.gz','wt') as z:
 for case in cert:z.write(json.dumps(case)+'\n')
out={'all_checks_passed':True,'ordered_pairs':count,'degree_matches':degree_count,'canonical_isomorphism_matches':iso_count,'degree_matches_with_at_least_one_individually_degree_distinguished_map':compensated,'seconds':time.perf_counter()-start};(R/'independent_output.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
