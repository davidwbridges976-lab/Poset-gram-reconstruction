# Endpoint-saturated eight-label fibers and complete two-base degree classification

David Bridges - 3 October 2026. Completed attack from frozen v141; pending freeze and direct scope review. Canonical packet and GitHub unchanged during the attack.

## Target, result and scope

Analyze middle attachments under the full degree filter in the endpoint-saturated size-eight class n=8|R_0|=8|R_7|. Result: an analytic common eight-label fiber decomposition for every finite endpoint count p; and a complete classification for p=1,2. At p=2, every valid pair is represented by a rank-preserving monotone map B_3 to B_3. Exactly 66 maps occur; 30 give equal degree multisets, and all 30 pairs are isomorphic by retained exact certificates. There is no nonisomorphic degree-matched pair in this complete p=2 class.

This closes the endpoint-saturated p<=2 subcase. It does not prove the full endpoint-saturated theorem for p>=3, the unsaturated size-eight theorem or general G-plus-degree injectivity. The preserved G-only collision is one of the other 36 maps and remains valid. The new universal fiber lemma is analytic; the two-base degree classification is computer-assisted with a coverage proof, not an arbitrary-n extrapolation.

## Checkpoint and dependencies

The v141 ZIP's CRC and every SHA256 manifest entry were checked before the main execution. Its roadmap selects endpoint-saturated middle-sector compatibility. The current block theorem, Boolean factor lemma, size-eight sector/interval theorem, counterexample status and dependency boundaries were retraced. No historical universal injectivity, q=2/L=4, physics or external novelty claim is imported. Earlier proof files and canonical packet remain untouched.

## Saturation gives a full endpoint matching

Use the frozen notation A_st,B_st,X_s for the eight sectors, with cube ranks r_s. Set p=|R_0|=|R_7|, n=8p. Frozen endpoint factors have seven copies of each X_0 column across all outside columns, and likewise for X_7 in Q. There are exactly 7p outside columns. Thus neither concatenated factor has a zero column.

In particular J=A_0,7 has p nonzero columns. The frozen rectangular partial matching H=X_0^(-1)J is now square, with a unit in every column and at most one unit in each row. Hence H is a permutation. Its two endpoint orders are isomorphic by the retained both-order transitivity argument. Relabel R_7 through this matching so X_0=X_7=X, J=K=X and H=I. This relabeling is a coordinate choice, not an assertion that the complete orders are isomorphic.

## Two endpoint column assignments coincide

Let c_a and t_a be the matched labels in R_0 and R_7. For every label i, the column of its P relations from R_0 is a unique column a(i) of X. The Q relations from R_7 similarly select a unique column c(i) of X. These columns are nonzero by endpoint saturation; zeta columns are distinct. Each P and Q assignment takes every base value exactly eight times, counting the diagonal endpoint columns along with their seven external copies.

The 0s block equation, after cancelling the invertible X, gives for i in R_s and each base label a

    number of P-upset labels j with a(j)=a
        = 2^(3-r_s) B_s0(i,c_a).

The 7s equation similarly gives

    number of Q-upset labels j with c(j)=a
        = 2^r_s A_s7(i,t_a).

For clarity, these are integer cardinalities, not aggregate counts of paths. They follow by writing the endpoint relation rows as X times their unit-column assignment matrices and multiplying by the full rows from R_s.

The first count includes i in its own P upset, so i<=_Q c_a(i). The second includes i in its own Q upset, so i<=_P t_c(i). The defining endpoint assignments also give c_a(i)<=_P i and t_c(i)<=_Q i. Transitivity now yields

    X(a(i),c(i))=1 and X(c(i),a(i))=1.

Antisymmetry of the base poset forces a(i)=c(i). Thus the assignments agree label by label. This uses full exact block closure as well as both poset orders; endpoint column multiplicities alone would not suffice.

## Common fibers of exactly eight labels

Put F_a={i:a(i)=a}. Every F_a has eight labels and contains its matched endpoints c_a,t_a. In P,

    c_a <= i <= t_a for every i in F_a;

in Q the corresponding sandwich is t_a<=i<=c_a. If i in F_a is related below j in F_k in either order, their endpoint sandwiches force a<=k in the common base order X. Therefore both P and Q preserve the same base direction, even though cube-sector directions are reversed.

The endpoint rows into R_7 and R_0 are forced exactly: A_s7(i,t_k)=B_s0(i,c_k)=X(a,k). The forward direction follows from the sandwich and base transitivity; the converse follows by inserting the endpoint sandwiches into a hypothetical relation. Substituting in the two count identities gives

    |U_i(P) intersect F_k| = 2^(3-r_s) X(a,k),
    |U_i(Q) intersect F_k| = 2^r_s X(a,k),

for i in F_a intersect R_s. In particular each fiber's own upset sizes are 2^(3-r_s) in P and 2^r_s in Q. These formulas hold for all finite p under endpoint saturation.

They do not yet classify the order of every fiber at p>=3 or every relation between fibers. No one-label-per-sector assertion is made for a general fiber: the original collision's lower fiber has repeated sector profiles.

## Complete coverage at p=1 and p=2

At p=1, n=8 and the whole poset is the already classified cube interval, reversed in Q. The cube and its dual are isomorphic.

At p=2, the base poset X has a greatest label, because b is greatest in R_0. A two-label poset with a greatest label is a chain. Denote its lower and upper fibers F and S. The upper fiber is exactly the original anchor interval S=U_b(P), since the P upset of the upper base endpoint contains precisely those eight labels. It is the frozen cube B_3 with Q reverse.

Every i in F has its original sector profile U_psi(i) inside S; in Q it has Down_psi(i). The cross-fiber rows are therefore completely determined by psi. The fiber count formulas give internal F upset sizes u_i=2^(3-|psi(i)|) and v_i=2^|psi(i)|, respectively. There are no S-to-F relations in either order, because the base direction is preserved.

The P Gram block on F is its internal row Gram plus the cube-profile Gram of the U_psi(i). The Q block is its internal row Gram plus the profile Gram of Down_psi(i). The cube identity scales the latter external block by exactly the inherited factors sqrt(8)/u_i on each row. Subtracting these exact external blocks from the full block equality therefore leaves the same scaling equality for the internal F Grams. Their diagonals are u_i and v_i, with v_i=8/u_i. Thus the two internal normalized Grams are equal.

The endpoint sandwich makes F bounded in P with least c_0 and greatest t_0, and bounded in Q with the reversed endpoints. Its original upset of c_0 is all eight fiber labels, and c_0 is Q greatest. Hence the frozen interval/size-eight theorem applies locally: P on F is B_3 and Q is its exact reverse on the same labels. Choose cube coordinates x on F. Internal upset sizes now force |psi(x)|=|x|, and containment of cross profiles under P transitivity forces psi to be monotone under subset inclusion.

Conversely every rank-preserving monotone psi:B_3->B_3 yields a valid pair. In cube coordinates the P upset of a lower label x is

    U_x in F, together with U_psi(x) in S;

its Q upset is

    Down_x in F, together with Down_psi(x) in S.

Upper-fiber rows are U_y in P and Down_y in Q. Monotonicity verifies transitivity, while antisymmetry follows from the separate cube orders and one-way base direction. Rank preservation and the cube overlap identity verify normalized Gram equality for lower-lower, lower-upper and upper-upper pairs. Both anchors, sector profiles and n=16 endpoint saturation follow. This proves coverage of the complete p=2 candidate class after cube coordinate choices. It is stronger than sampling a chosen generator family.

## Exact six-degree filter

For a cube vertex x write u_x=2^(3-|x|), e_x=2^|x|. Lower-fiber degrees are 2u_x+e_x-2 in P and 2e_x+u_x-2 in Q. Their degree multisets are always the same:

    {6,6,6,8,8,8,8,15}.

The upper endpoints contribute {8,15} in both orders. Thus only the six upper middle labels need comparison.

For the three atoms a, put n_a=#{lower atoms x:psi(x)=a}. Put m_a=#{lower coatoms x:psi(x)=7 minus a}, where 7 minus a denotes the coatom missing that atom, in bit-mask notation 7 xor a. Then sum_a n_a=sum_a m_a=3. Direct incoming-relation counts give the remaining degree multisets

    P: {5+n_a, 8-n_a+m_a : a an atom},
    Q: {5+m_a, 8+n_a-m_a : a an atom}.

For example, an upper atom's P predecessors in F are the lower bottom and n_a atoms; an upper coatom's P predecessors are the bottom, the 3-n_a atoms mapped into it, and the m_a coatoms mapped to it. Q uses the reverse profile containments. Adding the common internal cube degrees gives precisely the displayed values.

Equality of these two six-element multisets is necessary and sufficient for full degree-multiset equality in the complete two-base class. It does not demand a supplied row correspondence or a bijective psi.

## Complete finite classification and isomorphism certificates

A rank-preserving map fixes 0 and 7. Each of three atoms has three possible atom images, and each of three coatoms has three possible coatom images. All 3^6=729 possibilities were checked for monotonicity. Exactly 66 pass. An independent enumeration chooses atom images first, then all admissible coatom supersets; it produces precisely the same 66 maps. Combinatorially the count is 6 distinct-atom-image maps, 36 maps with exactly two atom images, and 24 maps with a single atom image.

Every valid map was checked by full poset axioms, all 256 exact squared normalized Gram entries, full degree multisets and exhaustive order-isomorphism search. Exactly 30 maps have matching degrees. All 30 have retained explicit label bijections; each is verified against every relation. The other 36 have unequal degrees and therefore cannot be isomorphic. Six maps are cube automorphisms; the remaining 24 degree-matched cases have nonbijective psi but still isomorphic complete orders. No bijectivity theorem is claimed.

verify_degree_formula.py separately checks the derived six-degree formula against all 66 full-order degree certificates. It finds the same 30 matches. The analytic coverage proof above is essential to the scoped conclusion; the finite enumeration alone would only establish a generator-family result.

## Preserved collision and execution history

The original phi is [0,1,1,3,1,3,5,7]. Generated P and Q were verified byte-for-byte against the original zeta arrays copied from frozen v141. This map is among the 36 degree-distinguished nonisomorphic cases. The original G-only counterexample is unchanged and exact.

verify.py ran once successfully. Complete map certificates include both upset systems, degree multisets, isomorphism bijections and exhaustive-search node counts. verify_degree_formula.py ran once successfully. Supplemental verify_fibers.py checks the general common assignment, eight-label fiber counts, sandwiches and base-dependent upset counts on the original collision and five cube-product controls at n=8,16,24,24,32, with endpoint counts 1,2,3,3,4.

The first supplemental fiber run failed because the intended final diamond matrix omitted its fourth row. The failed source and stderr are retained; diagnose_fibers.py identified the fixture problem. A preliminary inline diagnostic also failed because its exec namespace omitted __file__; that error and code are retained. The corrected four-by-four diamond control then passed. This fixture correction changed no theorem, map enumeration, original collision or main certificate. No failed approach or correction is erased. Main and supplemental stdout, stderr, exact outputs and actual executed source are retained. No external literature or novelty audit occurred.

## Status and roadmap

CLOSED analytically for every finite p in the endpoint-saturated class: full endpoint matching; a common partition into eight-label fibers; shared base direction and exact per-fiber upset counts.

CLOSED with analytic coverage and complete finite exact certificates: endpoint-saturated p<=2 degree matching forces order isomorphism. At p=2 every valid pair is one of the 66 rank-preserving monotone-map constructions, modulo cube coordinates. This is a scoped n=16 classification, not general size-eight or arbitrary-n uniqueness.

OPEN: endpoint-saturated p>=3 middle-fiber compatibility and degree-matched alternatives; unsaturated size-eight candidates; larger even anchors; multiple maxima; general G-plus-degree injectivity. General G-only injectivity remains false. No minimum ambient collision-size claim is made.

NEXT proposed single attack: endpoint-saturated p=3 degree-filter compatibility, starting with the base order having two incomparable lower labels and one greatest label. Retain the original collision as a negative degree-matching control and cube products as positive controls. The three-chain base and general p remain separately open. NOT RUN. Freeze this completed attack before any next attack. No canonical promotion or public repository update during this attack.
