# Eight-sector exact block closure and degree filter

David Bridges — 3 October 2026. Completed attack from frozen v140; pending freeze and direct scope review. Canonical files and GitHub unchanged during this attack.

## Target and outcome

Derive full exact block closure for the eight-sector size-eight anchor reduction and expose the degree-matching constraint. Result: an all-finite-n necessary-and-sufficient block Gram test once the candidate blocks define the required two posets; forced sevenfold endpoint incidence-column replication; a partial endpoint order matching; endpoint cardinality bounds; and exact degree-polynomial and first-moment constraints. This does not classify every solution of the block system and does not establish degree-filter uniqueness. The original collision remains valid.

## Continuity and dependencies

The v140 ZIP was verified by CRC and every retained manifest hash before execution. The record was retraced through the direct recovery identities, counterexample and historical survival/dependency ledger, v129 complete maximum-anchor enumeration, v130 finite evidence, and the v131–v140 scoped analytic developments. The size-four Boolean-factor lemma was read in full and the v139 interval reciprocity proof and v140 sector reduction checked. No historical universal uniqueness, q=2/L=4 branch, physics interpretation or novelty claim enters this attack.

The program began with universal normalized-Gram reconstruction; the exact 16-label counterexample refuted that target. Current work concerns surviving reconstruction data and the unresolved addition of unordered comparability degrees. A scoped structural consequence or finite control is not a general uniqueness theorem.

## Hypotheses and block notation

P,Q have the same strictly positive normalized principal-upset Gram matrix on the same finite labels. Their greatest elements are m,b respectively, and |U_b(P)|=8. Frozen v140 gives S=U_b(P)=U_m(Q), with P order B_3 and Q its reverse. Write the cube vertices as subsets s of a three-element set and r_s=|s|. The eight nonempty sectors R_s have common induced zeta matrices X_s. In P, a cross relation from R_s to R_t requires s subset t; in Q it requires t subset s.

Let A_st and B_st be the Boolean relation blocks of P and Q, with rows R_s and columns R_t. Their diagonal blocks both equal X_s. All forbidden-direction blocks vanish. The inherited full upset-size ratio on R_s is

    d'_i/d_i = 2^(2r_s-3).

Candidate blocks must satisfy reflexivity, antisymmetry and transitivity in both orders; allowed directions alone do not ensure this. In matrix form transitivity is: whenever (A_st A_tu)_ij>0, (A_su)_ij=1, for every s,t,u,i,j; the same condition holds for B. This ordinary matrix product counts intermediate witnesses, not just a single edge. The distinguished cube interval, profiles, greatest anchors and its original size eight must also be retained for the stated anchor class.

## Exact block closure: all 64 equations

Put

    C_st = sum_(u containing s union t) A_su A_tu^T,
    E_st = sum_(u contained in s intersect t) B_su B_tu^T.

These are exactly the st blocks of Z_P Z_P^T and Z_Q Z_Q^T: columns in any other sector contribute zero by the direction restrictions. Equality of normalized Gram entries and the inherited size ratios gives

    E_st = 2^(r_s+r_t-3) C_st,

or, without fractional coefficients,

    8 E_st = 2^(r_s+r_t) C_st.

Every ordered pair s,t is covered. The diagonal equations imply the required full row-size ratios, because the diagonal of a Boolean row Gram product is its row sum. Conversely, for two valid candidate poset matrices, these equations imply d'_i=2^(2r_s-3)d_i and then equal normalized Gram entries: dividing E_ij by sqrt(d'_i d'_j) cancels precisely the displayed block scaling. All counts are nonnegative, so there is no sign ambiguity. Thus the complete block system is a necessary-and-sufficient Gram equality test in this candidate class, not merely a list of necessary overlaps. It is not an existence or uniqueness solution of the system.

Integrality additionally requires every C_st entry to be divisible by 2^(3-r_s-r_t) when r_s+r_t<3. This follows directly from the same equations; when the rank sum is at least three that particular divisibility condition is empty. The equations still constrain all rank pairs.

## Sevenfold endpoint column replication

For the empty vertex 0, Q has no outgoing block beyond its diagonal X_0. The 00 equation gives

    sum_(t != 0) A_0t A_0t^T = 7 X_0 X_0^T.

Concatenate all seven outgoing P blocks. This Boolean matrix satisfies the frozen Boolean-factor lemma with replication factor seven. Consequently it consists of exactly seven copies of every column of X_0 and possible zero columns, in any column order. This is an analytic all-finite-size result; no assumption that those columns are downsets is needed for the factor lemma.

At the full vertex 7, P has no outgoing block beyond X_7. The 77 equation similarly gives

    sum_(t != 7) B_7t B_7t^T = 7 X_7 X_7^T.

Thus the concatenated outgoing Q blocks have exactly seven copies of every X_7 column and possible zero columns. Since the number of available outside columns is n-|R_0| or n-|R_7|, respectively,

    n >= 8|R_0|,    n >= 8|R_7|.

The lemma is inherited with its analytic maximal-row deletion proof. Reuse here is scoped to Boolean endpoint factors; it does not assert normalized reconstruction.

## Partial endpoint matching and its order meaning

Set J=A_0,7 and K=B_7,0. The 07 equation has scaling one and reads

    X_0 K^T = J X_7^T.

Because J columns are X_0 columns or zero, define H=X_0^(-1)J. Every H column is a positive unit vector or zero, and J=X_0 H. Invertibility of X_0 in the displayed equality gives K=X_7 H^T. The endpoint factor classification for K now says each H^T column is a unit vector or zero. Hence every row and column of H contains at most one one: H is a rectangular partial matching, not automatically a square permutation.

The interval endpoints b in R_0 and m in R_7 are matched. Indeed J's m column is all ones because m is P greatest; X_0's b column is all ones because every R_0 label lies below b in P, by its profile. Therefore H maps the m column to the b row. Their Q relationship agrees with K.

This matching is an order isomorphism on the induced sets of matched endpoint labels. If i corresponds to j and k to l, then J_ij=K_ji=J_kl=K_lk=1. If X_0(i,k)=1, Q transitivity along j<=i<=k gives K_jk=1, hence X_7(j,l)=1. Conversely X_7(j,l)=1 and P transitivity along i<=j<=l give J_il=1, hence X_0(i,k)=1. No relation is asserted for unmatched labels, and no extension to all middle sectors follows. Even a full endpoint matching would not itself prove full order isomorphism: the original nonisomorphic collision has a full two-by-two endpoint matching.

## Exact comparability-degree filter

For i in R_s, let alpha_i be its degree in the common induced sector order. Then

    gamma_P(i) = alpha_i
                 + sum_(t != s) row_sum_i(A_st)
                 + sum_(t != s) column_sum_i(A_ts),

and gamma_Q has the identical formula with B. Terms in forbidden directions vanish. Both formulas count every other comparable label once, by antisymmetry.

The unordered degree multisets agree if and only if the finite integer polynomials agree:

    sum_i z^gamma_P(i) = sum_i z^gamma_Q(i).

This supplies an exact filter on complete block solutions without inventing a row correspondence. A first-moment equality is necessary but is not the whole filter.

Put D_r=sum_(i in rank-r sectors) d_i. Since sum_i gamma(i)=2(sum_i d_i-n), equality of the degree sums requires

    -7D_0 - 4D_1 + 8D_2 + 56D_3 = 0.

This is eight times the difference of the two total upset-size sums, using rank ratios 1/8,1/2,2,8. It is distinct from the inherited sector-cardinality balance -3N_0-N_1+N_2+3N_3=0. Both are necessary conditions here; their logical independence has not been proved in this attack. Neither is a substitute for the full polynomial filter.

## Exact verification and controls

verify.py executed once. The frozen parent ZIP's CRC and every manifest hash passed. The original counterexample input was copied byte-for-byte from that ZIP. Its two matrices were independently checked as posets, all exact squared normalized Gram entries compared, sector profiles reconstructed, all 64 block identities verified against direct full-matrix intersection counts, both endpoint replication patterns recorded, the partial matching checked, and degree block formulas checked against direct full-order degrees.

The same checks ran on five cube-product controls based on a singleton, a two-chain, a three-chain, a three-element order with two incomparable lower labels and a greatest element, and a four-element diamond. Their ambient sizes are 8,16,24,24,32. All five have matching full degree multisets. These are constructed implementation controls, not an exhaustive ambient population or a classification of solutions.

Total: six cases and 384 exact ordered block identities. All checks passed; no failed execution or editing correction. Complete Boolean blocks, all intersection block certificates, endpoint column multiplicities, matching pairs, degree polynomials and moments are retained with actual source, stdout and empty stderr.

The original collision remains exact and distinguished by degree data. Its degree first moments both equal 130, but its second moments are 1198 and 1194. Thus it passes the new first-moment condition while failing the full degree-polynomial equality. Its endpoint sizes are both two, saturating n>=8|R_0| and n>=8|R_7| at n=16. Its endpoint H is a full matching. These stronger necessary endpoint facts therefore do not rescue G-only uniqueness or establish degree-filter uniqueness.

## Status and next frontier

CLOSED under the stated hypotheses: exact necessary-and-sufficient block Gram equations for valid candidate orders; sevenfold endpoint column factors; partial endpoint order matching; endpoint size bounds; exact degree-polynomial test and its first-moment balance. Analytic consequences hold for all finite n; finite controls do not carry that universal proof burden.

OPEN: classification of all compatible middle-sector attachments solving those equations; whether their full degree-polynomial equality forces isomorphism; larger even anchor sizes; multiple maxima; general G-plus-degree injectivity. General G-only injectivity remains false. No novelty audit, literature search, historical q=2/L=4 import or canonical promotion.

NEXT proposed single attack: middle-sector attachment compatibility under the full degree-polynomial filter, beginning with the endpoint-saturated size-eight class n=8|R_0|=8|R_7|; retain the original n=16 collision as a negative degree-matching control and cube products as positive controls. This is a scoped entry case, not a claim that all size-eight candidates are endpoint-saturated. NOT RUN. Freeze this completed attack before proceeding.
