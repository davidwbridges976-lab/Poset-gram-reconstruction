# Size-four all-extreme-sizes Boolean-factor rigidity

David Bridges - 3 October 2026. Completed attack; pending freeze and direct scope review. Parent frozen v137. No canonical or GitHub write during this attack.

## Exact target and outcome

Attack the remaining p>=5 non-permutation factors using a general consequence of the incidence-factor constraints. Result: an analytic Boolean Gram-factor uniqueness lemma and full size-four alternative-anchor isomorphism for every finite total n and every finite extreme-sector size p. No p=5 enumeration was required or run. The former p>=5 size-four obstruction is closed under the stated positive-entry G hypotheses. General G-plus-degree injectivity remains OPEN. General G-only injectivity remains false. No degree matching, historical q=2/L=4, quarantined physics or novelty claim.

## Precise Boolean-factor lemma

Let R be any finite poset on k labels, X its principal-upset zeta matrix (X_ij=1[i<=j]), and r a positive integer. Let A be any Boolean k-by-s matrix, with any finite number s of columns. If

    AA^T = r XX^T,

then, up to column permutation, A consists of exactly r copies of every column of X, together with any number of zero columns. No downset hypothesis on the columns of A is required. This conclusion concerns a supplied zeta factor X; it does not identify a normalized Gram realization or prove general normalized injectivity.

## Analytic proof by maximal-row deletion

The k=0 case has only zero-length columns. For nonempty R choose a maximal label m. Its X row is the unit row at m, so (AA^T)_mm=r. Because A is Boolean, exactly r columns have entry one in row m. Let I_m be their column indices.

For every label i,

    sum_(j in I_m) A_ij = (AA^T)_im = r(XX^T)_im = r X_im.

The sum has exactly r Boolean terms. If X_im=1 they are all one; if X_im=0 they are all zero. Thus every column indexed by I_m is exactly column m of X, on all row labels. This inference uses Boolean entries and an exact equality; an arbitrary real or integer factor is not covered.

Delete those r columns and row m. Let X0 be the zeta matrix of the induced order on the remaining labels. In label order remaining,m,

    X=[[X0,u],[0,1]],

where u is the remaining part of column m. Removing its r known copies subtracts r uu^T from the remaining Gram block, leaving exactly r X0 X0^T. The remaining Boolean matrix therefore satisfies the same hypothesis on k-1 labels. Induction gives r copies of each induced zeta column and zero columns. Its deleted m row was zero on every remaining column by construction, so the induced columns lift to the corresponding original X columns with a zero at m. Hence the conclusion holds on all k labels. Repeated deletion terminates because k is finite.

This is a direct all-finite-k argument. It is not inferred from the computations below. The zero columns remain harmless and explicitly included.

## Application to every size-four alternative anchor

P,Q are finite posets on the same labels with exactly equal strictly positive normalized principal-upset Gram matrix G. P has greatest m and Q greatest b. Assume the original P upset of b has size four. Frozen v132-v133 prove its diamond {b,a,z,m}, the sectors C,A,B,T and equal extreme sizes |C|=|T|=p. Let M=A union B. Both orders have common induced zeta matrices X,V,Y on C,M,T, and

    Z_P=[[X,L,J],[0,V,E],[0,0,Y]],
    Z_Q=[[X,0,0],[F,V,0],[K,W,Y]].

The exact square-root size transport is 1/2 on C, 1 on M and 2 on T. The CC Gram equality therefore gives the frozen identity

    3XX^T = LL^T + JJ^T.

The horizontal Boolean matrix A_star=[J L] satisfies A_star A_star^T=3XX^T. Apply the new lemma with r=3. Every column of J is either a column of X or zero. Consequently every column of the square integer matrix H=X^-1 J is a positive unit vector or zero.

Frozen v135 proves H invertible modulo two using the middle equation: with B=X^-1 L and A0=V^-1 E, B=H A0^T modulo two, so HH^T+BB^T=3I implies H(I+A0^T A0)H^T=I modulo two. Hence det(H) is odd and H has full real rank. A square matrix whose columns are unit vectors or zero has full rank only when no column is zero and no two select the same unit vector. Therefore H is a genuine permutation matrix for every finite p.

Frozen v136, independently proved from both-order transitivity, integer parity and the middle-block norm identities, shows that permutation H forces the full explicit order isomorphism: exchange the C and T sectors through their forced matching and fix every middle label. Thus P and Q are isomorphic for every finite n, with no bound on p.

All ingredients are directly proved surviving statements in v132-v136. No historical universal uniqueness, q=2 transport or L=4 branch is imported. The size-four anchor is an original upset cardinality, not the historical transport parameter.

## Additional forced factor structure

The lemma gives exactly three copies of each X column across [J L]. Since J contains exactly one copy of each through its permutation, L contains exactly two copies of every X column, together with possible zero columns. Thus B=X^-1 L has exactly two unit columns for each C label, with zero columns allowed. This is a necessary structural classification of the C-to-middle block; it does not assert that all choices of those columns and middle orders produce valid realizations.

The paired T-side statement follows from 3YY^T=KK^T+WW^T and K=YH^T: W has exactly two copies of every Y column, plus zeros. The already proved full correspondence matches L with W under the sector isomorphism. Neither this factor description nor the existence of labeled ambiguity asserts a nonisomorphic collision.

## Exact execution and reproducibility

verify.py executed once. It checks the maximal-row deletion algorithm with exact integer Gram equalities on every one of the 1678 valid size-four anchors in the unchanged retained v130 ledger. It records the selected row, identified factor columns, original expected zeta column, zero columns, C/T matching and explicit order isomorphism for every case in ledger_peeling_certificates.jsonl.gz.

It also checks 1628 shuffled repeated-column controls: every naturally labeled poset of sizes 1 through 5, replication r=1,2,3,4, and two additional zero columns, with fixed random seed 137. These are implementation controls constructed from the lemma's proposed factor structure, not a uniqueness search.

An independent Boolean factor-multiplicity search covers 30 cases: every naturally labeled poset of sizes 1 through 3 and r=1,2,3. It enumerates all nonzero Boolean column patterns and all nonnegative multiplicities allowed by the target Gram entries. Each case has exactly one multiplicity solution, equal to r copies of the zeta columns. This search supports the new lemma without assuming its factor structure; it is finite evidence only.

All checks passed. Actual source, exact_output.json, stdout, empty stderr, deterministic control generation and complete ledger certificates are preserved. No failed execution or editing correction occurred. No new full-poset exhaustive n population was generated. The ledger is copied unchanged. No literature source was used. Novelty and priority were not assessed in this attack.

## Closure, limits and roadmap

CLOSED by analytic proof for all finite n: every valid original size-four alternative greatest-element anchor under positive-entry G yields an isomorphic order, for arbitrary finite p. The Boolean-factor lemma holds for any finite poset and positive integer replication factor. The former p>=5 size-four obstruction is removed, rather than advanced to a larger p.

Combining this with frozen size-two isomorphism and odd-anchor exclusion, any nonisomorphic positive-entry alternative greatest anchor must have EVEN original upset size at least SIX. This lower bound uses original upset size; it is distinct from the now unrestricted extreme-sector count p in the size-four theorem.

OPEN: original anchor sizes six, eight and larger even values; possible nonisomorphic degree-matched alternatives; multiple-maximal-element inputs; general G-plus-degree injectivity. G-only reconstruction remains false. The verified original 16-element collision uses an alternative original upset size eight and remains valid. No general uniqueness, physical interpretation or novelty claim is made.

The v137 p=4 computer-assisted certificates and all earlier p-bounded results remain historical evidence, preserved unchanged. They are covered by this stronger proof; they are not erased or relabeled as analytic executions.

Next proposed single attack: original anchor size SIX structural analysis. NOT RUN. Freeze this completed general size-four closure before proceeding. No new canonical version or public repository update during the attack.
