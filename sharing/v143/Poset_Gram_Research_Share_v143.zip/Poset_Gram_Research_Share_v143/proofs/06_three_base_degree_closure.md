# Endpoint-saturated three-base order with two incomparable lower labels: degree-filter closure

David Bridges - 3 October 2026. Completed attack from frozen v142; pending freeze and direct scope review. Canonical packet and public GitHub repository unchanged during this attack.

## Result and scope

The endpoint-saturated size-eight-anchor class whose common base has two incomparable lower labels and one greatest label is closed under the unordered comparability-degree filter: any such P,Q pair with equal normalized principal-upset Gram matrix G and equal degree multisets is isomorphic.

The proof gives complete coverage by pairs of rank-preserving monotone cube maps. All 66^2=4,356 ordered pairs were checked. Exactly 1,068 have matching degrees, and all 1,068 have explicit verified isomorphisms. An independent canonical-form and degree-formula implementation agrees on every pair. This is a computer-assisted closure of a precisely specified n=24 subcase, not an exhaustive population of all 24-element posets or an arbitrary-n uniqueness theorem.

The three-chain base remains untested. Larger bases, unsaturated size-eight anchors, larger even anchors, multiple maxima and general G-plus-degree injectivity remain open. The original G-only collision remains valid and degree-distinguished.

## Checkpoint, assumptions and inherited fibers

The v142 ZIP was verified by CRC and every SHA256 manifest entry before execution. Its current roadmap selects saturated p=3, beginning with this base order. Actual v142 map certificates and the unchanged original counterexample input were copied from the frozen ZIP. The 66-map list was independently regenerated from all 729 rank-preserving cube choices.

P,Q are finite posets on the same labels, with exactly equal positive-entry normalized principal-upset Gram matrix. P has greatest m, Q greatest b, and |U_b(P)|=8. Endpoint saturation means n=8|R_0|=8|R_7|. Frozen v142 gives the common base assignment, eight-label fibers F_a, the same base direction in both orders, and

    |U_i(P) intersect F_k| = 2^(3-r_i) X(a,k),
    |U_i(Q) intersect F_k| = 2^r_i X(a,k).

Here r_i is the inherited cube-profile rank and i lies in F_a. For this attack X has three labels 0,1,2, with 0<2 and 1<2, while 0 and 1 are incomparable. Denote the fibers by F,H,S respectively. There are no F-to-H or H-to-F relations in either order. S is precisely the original eight-label anchor interval, hence B_3 in P and its same-label reverse in Q.

No historical universal injectivity, q=2/L=4 branch or physics import is used. No literature search, novelty audit or priority claim occurred.

## Complete reduction to two cube maps

Each of F and H has only its own fiber and S above it in the base order. Its relations into S are its inherited principal cube profiles: U_phi(i) in P and Down_phi(i) in Q. Its own upset sizes are 2^(3-r_i) and 2^r_i.

For either lower fiber, subtract those external cube-profile Gram blocks from the full Gram equality. The cube profile identity scales their overlaps by exactly the inherited row factors, so the remaining internal Grams have equal normalized entries. The endpoint sandwich makes that lower fiber a bounded eight-label order, with the least endpoint in P becoming greatest in Q. The retained interval-reciprocity and size-eight theorem therefore identifies its P order as B_3 and its Q order as the exact reverse. Its profile map into S is rank-preserving by the internal upset sizes and monotone by transitivity.

Choose cube coordinates x independently on F,H,S. Thus every pair in the stated class is represented by two rank-preserving monotone maps phi,psi:B_3->B_3. The lower F row is

    P: U_x within F and U_phi(x) within S,
    Q: Down_x within F and Down_phi(x) within S;

H uses psi in the same formulas. S rows are its own U_y or Down_y. This covers every valid pair in the class after coordinate choices; it is not merely a selected generator family.

Conversely every such map pair defines valid posets. Monotonicity gives transitivity within and into S; no relation crosses between the two lower fibers. The cube overlap identity verifies all normalized Gram blocks. For F against H, the only common upset labels are in S, so the same cube identity verifies this remaining cross block too. P greatest is the upper cube's full vertex, Q greatest its empty vertex. Both endpoint counts are three and n=24, so saturation and the original anchor size eight hold.

## Exact degree filter

Each lower fiber contributes the same degree multiset to P and Q:

    {6,6,6,8,8,8,8,15}.

Both lower contributions may therefore be cancelled when comparing the complete degree polynomials. The upper endpoints contribute {9,23} in both orders.

For each of the three upper atoms a, let N_a count lower atoms from BOTH maps whose image is a. Let M_a count lower coatoms from BOTH maps whose image is the upper coatom missing a. Then sum N_a=sum M_a=6. The six upper middle degrees are

    P: {6+N_a, 12-N_a+M_a : a an atom},
    Q: {6+M_a, 12+N_a-M_a : a an atom}.

These formulas count the two lower bottom predecessors, the relevant atom/coatom images, and the upper cube's internal degree four. Q uses the reversed containments. Equality of these two six-element multisets is necessary and sufficient for full degree-multiset equality in this class. No row assignment is supplied or assumed.

## Complete isomorphism search

Both complete orders have exactly two minimal elements, one in each lower fiber. A label in S has both minima as predecessors, while a lower-fiber label has precisely its own minimum. Therefore any order isomorphism must preserve S and either preserve or exchange F,H. These fibers are intrinsic to the order; the search does not assume a hidden coordinate correspondence.

An isomorphism from a cube to its reversed cube is complement followed by one of the six coordinate permutations. Hence all possible full isomorphisms are among

    2 lower-fiber permutations times 6^3 cube coordinate choices = 432.

For source map f and target map g, a chosen upper coordinate permutation pi and lower permutation tau preserve cross relations exactly when

    pi(f(x)) = complement(g(complement(tau(x)))) for all eight x.

verify.py checks every admissible lower permutation for every map pair and upper permutation, then both lower-fiber assignments. Every reported isomorphism is additionally checked directly against all 576 full-order relations. If no structural candidate exists, completeness of the intrinsic fiber argument excludes any other isomorphism.

The independent implementation instead complements Q into ordinary cube coordinates, replacing each map f by its complement conjugate f*(x)=complement(f(complement(x))). It computes a canonical pair of maps under independent lower coordinate permutations, one common upper permutation and lower-fiber exchange. It compares the P canonical form against the complemented Q canonical form. This is a separate canonical-form implementation of the complete finite group action, rather than reusing the first search's compatibility cache or its returned isomorphisms.

## Exact execution and outcomes

verify.py ran once successfully. It checked all 4,356 ordered map pairs as full posets, all 300 upper-triangular exact squared-Gram comparisons per pair, direct full-order degree multisets, the intrinsic minimal-element partition, and complete structural isomorphism. Its gzip ledger retains every map-pair index, both degree multisets, status and explicit isomorphism when present. The copied full 66-map input and actual construction code make every order reproducible. The complete cube-map compatibility table is retained.

Results: 1,068 pairs match degrees, all 1,068 are isomorphic, and zero are nonisomorphic degree matches. The other 3,288 pairs have different degree multisets and cannot be isomorphic. The counts are representation-pair counts, not counts of unlabeled posets or entire Gram fibers.

independent_verify.py ran once successfully. On all 4,356 pairs it verifies the six-degree formulas against the direct full-order degree ledger and checks the independent canonical forms. It obtains the same 1,068 degree and isomorphism matches. All canonical forms and aggregate counts are retained in an independent gzip ledger.

There are 432 degree-matched pairs containing at least one map that, individually in the two-base construction, had unequal degree multisets. Degree compensation across lower fibers does occur. In every such case the complete 24-label orders are nevertheless isomorphic; compensation did not produce a collision. This conclusion is scoped to the complete tested class.

The 36 pairs of bijective cube maps supply positive degree/isomorphism controls. The original 16-label matrices were rechecked directly from the unchanged input: both are posets with exactly equal G and different degree multisets. They remain a genuine G-only counterexample. This attack does not remove or reinterpret it.

Full actual source, parent verification, copied inputs, both stdout/stderr records, exact outputs, compatibility table, complete pair ledger and independent canonical/degree ledger are retained. No failed execution or editing correction occurred. No full n=24 ambient exhaustive population, three-chain test or p>=4 test ran.

## Status and next step

CLOSED with analytic coverage and exact computer-assisted certification: endpoint-saturated size-eight anchors whose common base has two incomparable lower labels and one greatest label, with unordered degree matching. In this class degree matching forces order isomorphism.

OPEN: the endpoint-saturated three-chain base; general larger bases; unsaturated size-eight anchors; larger even anchors; multiple maxima; general G-plus-degree injectivity. G-only injectivity remains false. Prior analytic fiber decomposition and p<=2 classification remain intact.

NEXT proposed single attack: endpoint-saturated three-chain middle-attachment compatibility and full degree filter. No claim is made in advance that it reduces to independent map pairs. NOT RUN. Freeze this completed three-base subcase before proceeding. Canonical and GitHub files remained unchanged during the attack.
