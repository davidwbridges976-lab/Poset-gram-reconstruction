# Size-six anchor interval-reciprocity exclusion

David Bridges - 3 October 2026. Completed attack; pending freeze and direct scope review. Parent frozen v138. No canonical or GitHub modification during this attack.

## Target and outcome

Analyze a valid alternative greatest-element anchor whose original upset has size six. Result: no such alternative anchor can exist, for any finite total n, under exact positive-entry normalized principal-upset Gram data. This excludes even isomorphic size-six alternatives, not merely nonisomorphic ones. The proof uses a general anchor-interval reciprocity lemma and an analytic six-element overlap contradiction. General G-plus-degree injectivity remains OPEN. No degree hypothesis, historical q=2/L=4 or physics import; no novelty claim.

## Exact assumptions

P,Q are finite posets on the same labels with exactly the same normalized principal-upset Gram matrix G, every entry positive. P has greatest m and Q greatest b. Let S=U_b(P), c=|S|, d_i=|U_i(P)| and t_i=|U_i(P) intersect S|. The retained anchor-size identity is

    d'_i=c d_i/t_i^2.

The exact saturation criterion in either realization is i<=j if and only if G_ij^2 d_i=d_j, using that realization's sizes. These identities follow directly from the greatest anchor and upset inclusion. No universal uniqueness is assumed.

## General anchor-interval reciprocity lemma

For i in S, transitivity gives U_i(P) contained in S, hence t_i=d_i and d'_i=c/d_i. In particular d'_m=c. Since m is greatest in P, G_mi^2=1/d_i for i in S. Therefore

    G_mi^2 d'_m=c/d_i=d'_i,

and saturation gives m<=_Q i. Thus S is contained in U_m(Q). Both sets have c elements, so U_m(Q)=S exactly. Every Q upset of an element of S is also contained in S.

For i,j in S, put k_ij=|U_i(P) intersect U_j(P)|. Q saturation gives

    G_ij^2 d'_i=d'_j
    iff [k_ij^2/(d_i d_j)] [c/d_i]=c/d_j
    iff k_ij^2=d_i^2
    iff k_ij=d_i
    iff U_i(P) is contained in U_j(P)
    iff j<=_P i.

Thus the induced Q order on S is exactly the reverse of the induced P order. Since all relevant upsets lie within S in both realizations, if u_i and e_i denote the upset and downset sizes in the induced P order, then

    u_i e_i=c for every i in S.

Moreover the normalized principal-upset Gram matrix of that bounded order must equal the normalized principal-downset Gram matrix on the SAME labels. This is necessary for every valid anchor, independent of total n. Size reciprocity alone is not sufficient.

The order on S has least element b and greatest element m. The lemma does not assert that every reciprocal bounded order extends to a valid pair P,Q, and does not classify all c.

## Analytic classification of the reciprocal six-element interval

Assume c=6. For each element u_i e_i=6. The endpoints have pairs (6,1) and (1,6). No internal element can have downset size one or upset size one, because b and m are respectively the unique least and greatest elements. Therefore every one of the four internal labels has either

    (u,e)=(3,2), or (u,e)=(2,3).

Call these lower and upper internal elements. A lower element's downset contains exactly b and itself, so no other internal predecessor is possible. Its upset contains itself, m and exactly one internal successor, which must be an upper element. An upper element's upset contains exactly itself and m; its downset contains b, itself and exactly one lower internal predecessor.

The lower-to-upper successor correspondence is therefore a bijection. Four internal labels split into two lowers and two uppers. There are no additional internal comparabilities. The order is precisely two parallel chains

    b < l_1 < h_1 < m,
    b < l_2 < h_2 < m,

sharing their endpoints. This argument classifies every reciprocal six-element bounded order, independently of labels and total n.

## Exact normalized-overlap contradiction

The two lower internal elements have P upsets {l_1,h_1,m} and {l_2,h_2,m}. Their intersection is {m}, giving

    G_P(l_1,l_2)=1/sqrt(3*3)=1/3.

The interval-reciprocity lemma forces their Q upsets to be the P downsets {b,l_1} and {b,l_2}. Their intersection is {b}, giving

    G_Q(l_1,l_2)=1/sqrt(2*2)=1/2.

These are unequal. No labels outside S can alter the calculation: the lemma already proved these upsets are entirely inside S in both orders. This contradicts exact equality of the full labeled G. Hence no valid original size-six anchor exists for any finite n. Relabeling a hypothetical pair to align its G does not evade the argument; the statement already treats every possible aligned anchor label b.

## Complete internal verification and controls

verify.py executed once. It enumerates all 4096 directed relation patterns on four labeled internal elements, imposing antisymmetry and transitivity to obtain all 219 labeled four-element posets. Adding a least and greatest element covers every bounded six-element order. Exactly 12 labeled candidates satisfy u_i e_i=6 for all labels. Each has the two-chain classification and squared-overlap mismatch 1/9 versus 1/4; zero have equal normalized dual Gram matrices.

The 12 complete candidate certificates retain all upsets/downsets, lower and upper labels, chain matching and the exact contradictory pair. This is a complete bounded internal check, not a search of ambient posets up to a cutoff n. The all-total-n conclusion rests on the analytic lemma and contradiction above.

Positive controls are Boolean lattices of sizes 1,2,4,8: all satisfy reciprocity and exact normalized dual-Gram equality. The six-element 2-by-3 product grid fails reciprocity, demonstrating that six elements and an order-dual construction alone do not satisfy the necessary conditions. These controls are not a classification of larger anchor intervals or a new collision search.

Actual source, stdout, empty stderr, exact_output.json and all six-element certificates are preserved. All checks passed; no failed execution or editing correction. No finite v130 ledger was reused. No literature source was used. Novelty and priority were not assessed.

## Consequences and remaining scope

CLOSED for every finite n: a valid positive-entry G alternative anchor cannot have original upset size six. The new interval reciprocity and exact reversal lemma applies to any original anchor size c, but only c=6 is classified and excluded in this attack.

Combining frozen size-two and size-four isomorphism with odd-anchor exclusion and this size-six impossibility, every NONISOMORPHIC positive-entry alternative greatest anchor has original upset size at least EIGHT, and it must be even. The preserved original 16-element G-only collision has a valid anchor with original upset size eight, so the anchor-size lower bound is sharp. This does not establish that 16 is the smallest possible number of labels in a collision.

General G-only reconstruction remains false. Whether two nonisomorphic realizations can share G and the unordered comparability-degree multiset remains OPEN. The known size-eight pair has different degree multisets; the general size-eight degree-filter question is not solved here. Multiple-maximal-element inputs and larger even anchors remain outside the closure.

Next proposed single attack: original size-EIGHT anchor interval structure and its relevance to degree-matched alternatives, using the new necessary reciprocity lemma and the preserved collision as a control. NOT RUN. Freeze this attack before proceeding. No new canonical version or public repository update during the attack.
