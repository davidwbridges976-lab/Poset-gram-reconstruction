# Size-eight Boolean interval and eight-sector reduction

David Bridges - 3 October 2026. Completed structural attack; pending freeze and direct scope review. Parent frozen v139. No canonical or GitHub modification during this attack.

## Exact target and outcome

Analyze original size-eight alternative anchor intervals and their relevance to degree-matched ambiguity. Result: an analytic all-finite-n classification of the anchor interval as the Boolean lattice B_3, and a complete eight-sector overlap-profile reduction for every ambient label. This is NOT a proof of size-eight isomorphism or degree-filter uniqueness. The known nonisomorphic size-eight-anchor collision satisfies the reduction and remains valid. No degree hypothesis, historical q=2/L=4 or physics import; no novelty claim.

## Inherited assumptions and interval reciprocity

P,Q are finite posets on the same labels with exactly equal strictly positive normalized principal-upset Gram matrix G. P has greatest m, Q greatest b. Let S=U_b(P), |S|=8, d_i=|U_i(P)| and t_i=|U_i(P) intersect S|. Frozen v139 proves U_m(Q)=S, the two induced orders on S are exact reversals, and each element s of S has original upset size u_s and downset size e_s satisfying u_s e_s=8. All relevant upsets of interval labels remain within S in both orders. The transport and determinant identities are

    d'_i=8d_i/t_i^2, product_i t_i^2=8^n.

No global uniqueness assumption enters these necessary identities.

## The eight-element interval is exactly B_3

The endpoints b,m have (u,e)=(8,1),(1,8). Each internal element has (u,e)=(4,2) or (2,4), since these are the only other positive integer factor pairs of eight and only the endpoints have singleton upset or downset.

An element with (4,2) has exactly b as strict predecessor and therefore is an atom. Its upset has itself, m and exactly two other internal successors, necessarily coatoms. An element with (2,4) has exactly m as strict successor and is a coatom; it has exactly two atom predecessors. Atoms cannot be comparable to one another, and neither can coatoms.

The atom-coatom incidence graph is bipartite with every vertex of degree two. Both sides have the same size, since counting edges gives twice the atom count equal to twice the coatom count. Six internal labels therefore split into three atoms and three coatoms. Each atom is below exactly two of the three coatoms and each coatom above exactly two atoms. The non-incidence graph is a perfect matching. This is K_(3,3) with a perfect matching removed, the unique such incidence structure up to relabeling.

Identify the atoms with the three singleton subsets of {1,2,3}, each coatom with its two atom predecessors, b with the empty subset and m with the full subset. The order is exactly subset inclusion on all eight subsets: B_3. This is an analytic classification for any finite ambient n, not a bounded ambient search.

## Every ambient overlap profile is principal

For any ambient label i, I_i=U_i(P) intersect S is an upset of B_3 containing m. Its size t_i must be a power of two, because the exact determinant equation has only the prime factor two on the right and each t_i is a positive integer. Thus t_i is 1,2,4 or 8.

The size-one upset is {m}. Every size-two upset is {one coatom,m}. The full size-eight upset is S. These are all principal upsets. A size-four upset is either a principal upset of one atom, or the exceptional set consisting of all three coatoms and m. To justify completeness, an upset containing an atom must contain that atom, its two coatoms and m, which already exhausts four positions; one containing no atom can only use the three coatoms and m. Other nonempty upset sizes are forbidden by the prime restriction.

The exceptional size-four profile is impossible. Pick any interval atom a, whose original upset size is d_a=4. This profile intersects U_a in exactly the two coatoms above a and m, a count of three. The exact transformed intersection count with a is

    K'_ia = 8 K_ia/(t_i d_a) = 8*3/(4*4) = 3/2.

It must be an integer in every finite-poset realization, a contradiction. The formula follows by scaling K with sqrt(d'_i/d_i)=sqrt(8)/t_i and sqrt(d'_a/d_a)=sqrt(8)/d_a, since interval upsets are inside S. It does not assume a rounded numerical Gram value.

Therefore I_i is U_s(P) for a unique cube vertex s. This defines eight sectors R_s covering all ambient labels. Each is nonempty because the interval vertex s lies in its own sector.

## Reversed profiles and transport factors

Write cube vertices as subsets or bit masks and put r=|s|. Its interval upset size is d_s=2^(3-r). Since I_i=U_s, t_i=d_s and

    d'_i/d_i = 8/d_s^2 = 2^(2r-3).

The four rank transport ratios are 1/8, 1/2, 2, 8. The exact square-root ratios are sqrt(8)/d_s. These scale full ambient upset sizes, not only the eight interval sizes.

For v in S, the transformed overlap count is

    K'_iv = 8 |U_s intersect U_v|/(d_s d_v).

On B_3 this equals |Down(s) intersect Down(v)|: the upset intersection has size 2^(3-|s union v|), so the displayed expression is 2^|s intersect v|. Let D_i=U_i(Q) intersect S. Since the Q interval order is the reverse, its counts |D_i intersect Down(v)| are exactly those values for every v. Counts against all principal downsets determine a subset uniquely by the invertible triangular zeta matrix, hence

    U_i(Q) intersect S = Down(s).

Thus the same sector label s has a principal upward profile in P and a principal downward profile in Q. No alternative profile is silently discarded.

## Exact order and cardinality restrictions

Both orders induce the same order inside each sector, since all its upset sizes and intersection entries scale by the same factor and saturation is preserved. Distinct sectors of the same cube rank have no relation between them in either order.

If i in R_s is below j in R_t in P, then U_j(P) is contained in U_i(P), so U_t is contained in U_s and s is a subset of t. If the relation holds in Q, the corresponding downset profiles require t to be a subset of s. Consequently cross-sector directions follow cube inclusion in P and reverse inclusion in Q. These are allowed directions only; they do not assert every allowed cross relation occurs.

Let N_r be the total number of labels in cube-rank-r sectors. Determinant balance gives

    -3N_0-N_1+N_2+3N_3=0.

Also n is even, since product_i t_i^2=8^n makes the exponent 3n even. No equality of all sector sizes, product decomposition or isomorphism follows from these equations. Known-collision sector sizes are unequal.

## Degree question and preserved collision

The cube interval's own comparability degrees are unchanged by reversal: endpoints have degree seven and atoms/coatoms degree four. Full ambient degrees also depend on attachments to other labels and on their induced sector orders. Those attachments remain unresolved; internal cube symmetry does not establish equality or inequality of full degree multisets in general.

For each row i, write alpha_i for its common within-sector comparability degree. Its full P degree is alpha_i plus all incoming and outgoing Boolean cross-sector incidences in P; its Q degree uses the corresponding reversed allowed blocks. Degree-multiset matching is equality of the multisets of these full totals, without a supplied row assignment. The eight-sector reduction makes these comparisons explicit but does not solve them.

The original 16-label collision was rechecked from unchanged source_zeta and candidate_zeta in the retained counterexample_input.json. Both orders are posets, all 256 exact squared Gram entries agree, the alternative anchor has original size eight, all eight profiles and transport restrictions hold, and the two degree multisets remain different. It is still a real nonisomorphic G-only collision, and it still does not refute G-plus-degree injectivity.

## Exact execution and controls

verify.py executed once. It checks all 512 labeled three-by-three atom-coatom graphs; exactly six satisfy degree two on both sides, and all six are the cube incidence pattern with reciprocal sizes and exact reversed normalized Gram equality.

It checks all 19 nonempty upsets of the cube. Ten are excluded by the determinant-prime condition, one exceptional size-four profile by a fractional transformed intersection, and precisely eight principal profiles remain. All profile certificates and rejection reasons are retained.

The original collision is checked as above. Independent product controls at n=8,16,24 with chain base sizes one,two,three and a cube factor verify equal G and all sector, direction, scale and balance restrictions. These are implementation examples, not exhaustive ambient classifications. Source, unchanged counterexample input, exact_output.json, stdout, empty stderr, all interval/profile/collision/control certificates are retained. All checks passed; no failed execution or editing correction. No literature source or novelty audit in this attack.

## Scope and next frontier

CLOSED for all finite n under valid original size-eight-anchor and positive-entry-G hypotheses: Boolean B_3 interval, exactly eight principal profile sectors, reversed profile identity, within-sector order preservation, opposite cube directions, rank scale factors and determinant balance.

OPEN: full eight-sector cross-block classification; whether any nonisomorphic size-eight alternatives can share the unordered comparability-degree multiset; larger even anchor sizes and multiple-maximal inputs; general G-plus-degree injectivity. The known collision remains valid. These local restrictions are necessary, not sufficient realization conditions and not a uniqueness theorem.

Next proposed single attack: exact eight-sector block closure with degree-multiset matching, using the original 16-label collision as a control. NOT RUN. Freeze this structural reduction before proceeding. No new canonical version or public repository update during the attack.
