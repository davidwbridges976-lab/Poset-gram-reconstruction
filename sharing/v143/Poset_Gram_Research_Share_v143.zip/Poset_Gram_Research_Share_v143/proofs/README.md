# Optional proof notes

For the latest result, read 06_three_base_degree_closure.md, especially its coverage and intrinsic-isomorphism arguments. The corresponding frozen scope review is in review/. The three-page entry PDF stands on its own as an overview; these are detailed proof sources.

Dependency order, if you want to audit the reduction:

1. 01_boolean_factor.md: Boolean-factor lemma and its induction proof. Its separate size-four application is additional context.
2. 02_anchor_interval.md: general interval reciprocity/reversal lemma. The size-six exclusion is additional context.
3. 03_cube_and_sectors.md: cube interval, principal profiles and sector transport.
4. 04_block_equations.md: complete block test and endpoint factors.
5. 05_saturated_fibers_and_two_base.md: common eight-label fibers and complete two-base coverage.
6. 06_three_base_degree_closure.md: complete two-map coverage, degree filter and intrinsic isomorphism test.

Reports are copied unchanged from the frozen v143 packet and retain their original pre-freeze dates/status wording. The adjacent review/ files record their frozen scope. These notes include scoped assumptions and earlier corrections; they are not a general uniqueness theorem, external peer review or novelty certification.
