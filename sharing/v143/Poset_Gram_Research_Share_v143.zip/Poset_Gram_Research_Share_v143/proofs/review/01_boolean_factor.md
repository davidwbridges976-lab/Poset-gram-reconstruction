# Frozen v138 - general size-four Boolean-factor rigidity

Start with 00_CURRENT_MATHEMATICS.pdf (37 pages). New analytic proof and scope review: pages 28-31. Every valid original size-four alternative greatest anchor under positive-entry G yields an isomorphic order for all finite n and all finite extreme sizes p. A Boolean factor of rXX^T consists of exactly r copies of every zeta column plus zeros; applying it to the CC block forces permutation H, and the retained correspondence proof gives the explicit swap isomorphism. The former p>=5 size-four obstruction is CLOSED, not advanced to another p.

Combining size-two isomorphism and odd-anchor exclusion, nonisomorphic positive-entry alternative anchors require EVEN original upset size at least SIX. General G-plus-degree injectivity remains OPEN; general G-only injectivity remains false; size-eight collision unaffected. Sizes six, eight and larger even anchors and multiple-maximal inputs remain outside this closure. No degree hypothesis, historical q=2/L=4 or physics import. Novelty unassessed.

New sources: 04_NEW_STRUCTURAL_RESULTS/Size_Four_All_Extreme_Sizes_Boolean_Factor_Rigidity_v138. Actual executed source verifies 1678 ledger peeling/swap cases, 1628 shuffled repeated-column controls and 30 independent exact small factor-multiplicity searches. Full ledger certificates, stdout, stderr and output preserved. Earlier bounded and computer-assisted proofs, corrections and cumulative history retained. Pages 32-37 preserve original cumulative 311-316.

Roadmap: v129 scoped imports; v130 finite verification; v131 size-two; v132 odd anchors; v133 diamond sectors; v134 singleton; v135 parity/p=2; v136 permutation correspondence/p=3; v137 incidence cone/p=4; v138 analytic general size-four closure. NEXT: original anchor size SIX structural analysis; NOT RUN. GitHub unchanged. Commentary mode active; no new attack authorized by this freeze.

Approved by direct Boolean maximal-row induction, exact block application, retained parity and full correspondence proof review; not external peer review.
