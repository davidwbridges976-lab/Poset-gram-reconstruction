# Frozen v139 - size-six anchor interval-reciprocity exclusion

Read 00_CURRENT_MATHEMATICS.pdf (41 pages). New proof and scope review: pages 32-35. Every valid alternative greatest-anchor interval must reverse exactly between the two orders, with upset-size times downset-size equal to its original cardinality c. At c=6 this forces two parallel chains and normalized overlap 1/3 versus 1/2, a contradiction. Size-six anchors are IMPOSSIBLE for every finite n, including isomorphic alternatives.

Nonisomorphic positive-entry alternatives now require EVEN original anchor size at least EIGHT. The retained size-eight collision attains this anchor-size bound, not a claimed minimum ambient n. General G-only injectivity remains false; general G-plus-degree injectivity is OPEN. No degree hypothesis or historical q=2/L=4 import.

New sources: 04_NEW_STRUCTURAL_RESULTS/Size_Six_Anchor_Interval_Reciprocity_Exclusion_v139. Complete exact internal verification: 4096 relation patterns, 219 interior posets, 12 reciprocal candidates, all 12 excluded. All certificates, source, stdout, stderr and exact output retained. Earlier analytic/bounded proofs and cumulative history preserved. Pages 36-41 retain original cumulative 311-316.

Roadmap: v129 scoped imports; v130 finite verification; v131 size-two; v132 odd anchors; v133 diamond sectors; v134 singleton; v135 p=2; v136 p=3; v137 p=4; v138 analytic general size-four; v139 interval reciprocity and size-six impossibility. NEXT: size-EIGHT anchor interval structure and degree-matched alternatives, using the retained collision as control; NOT RUN. GitHub unchanged.

Approved by direct anchor-interval equality, reversed-order reciprocity, six-element classification and exact overlap contradiction proof review; not external peer review.
