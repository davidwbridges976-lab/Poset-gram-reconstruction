# Frozen v142 - endpoint-saturated eight-label fibers and two-base degree classification

Read 00_CURRENT_MATHEMATICS.pdf (59 pages). New proof and scope review: pages 47-53. Under endpoint saturation n=8|R_0|=8|R_7|, the endpoint matching is full, the two base assignments agree label by label, and every base fiber has eight labels. Both orders preserve the base direction and have exact per-fiber upset counts. This decomposition is analytic for all finite base counts p; it does not classify every middle attachment.

Complete p<=2 result: degree-matched pairs are isomorphic. At p=2, n=16, every valid pair reduces to a rank-preserving monotone cube map. All 729 possible rank-preserving maps were checked; 66 are monotone. Exactly 30 have matching degrees and all 30 have verified isomorphism bijections. Six maps are bijective and 24 further degree-matched maps are nonbijective. The other 36 have different degree multisets. The original collision is preserved exactly among those 36. G-only injectivity remains false; general G-plus-degree injectivity remains OPEN.

Execution: verify.py once, independent map enumeration, exact poset/Gram/degree and exhaustive isomorphism checks; verify_degree_formula.py once checks all 66 six-degree formulas; corrected verify_fibers.py checks the original collision and five product controls. Its initial malformed diamond fixture and failed preliminary diagnostic are preserved with the correction record. No p>=3 search or literature/novelty audit ran.

Roadmap: v129 scoped imports; v130 finite; v131 size-two; v132 odd; v133-v138 size-four development and full closure; v139 size-six exclusion; v140 cube/sectors; v141 exact block closure; v142 saturated fibers and complete p<=2 degree filter. NEXT: saturated p=3 degree compatibility, beginning with the base order of two incomparable lower labels and one greatest label. The three-chain base, larger p, unsaturated size-eight class, larger even anchors and multiple maxima remain open. NOT RUN.

All earlier evidence is preserved byte-for-byte, with superseded reader files historical. Original cumulative pages 311-316 remain on pages 54-59. Sources: 04_NEW_STRUCTURAL_RESULTS/Endpoint_Saturated_Eight_Fibers_Two_Base_Degree_Classification_v142. No historical q=2/L=4 or physics import, general uniqueness claim, public repository update or next attack.

Direct review approves the analytic fiber decomposition and complete scoped p<=2 classification with finite isomorphism certificates; no p>=3 or unsaturated closure. Not external peer review.
