# Frozen v140 - size-eight Boolean interval and eight-sector reduction

Read 00_CURRENT_MATHEMATICS.pdf (46 pages). New proof and scope review: pages 36-40. Every valid original size-eight alternative anchor has Boolean B_3 interval. Every ambient label has exactly one of eight principal overlap profiles, reversed to the matching downset in Q. Both orders preserve each sector order; cross directions follow subset inclusion in P and reverse inclusion in Q. Rank scale ratios are 1/8,1/2,2,8 and determinant balance is -3N0-N1+N2+3N3=0; n is even. These are necessary constraints, not isomorphism or degree-filter uniqueness.

Original 16-label collision rechecked: both orders valid, all 256 exact squared Gram entries agree, all sector restrictions pass, and degree multisets remain different. General G-only injectivity remains false; general G-plus-degree injectivity remains OPEN. Nonisomorphic positive-entry alternatives require even original size at least eight. No equal-sector/product claim or historical q=2/L=4 import.

New sources: 04_NEW_STRUCTURAL_RESULTS/Size_Eight_Boolean_Interval_Eight_Sector_Reduction_v140. Full code, unchanged collision input, certificates, stdout, stderr and exact output retained. 512 bipartite graphs, six reciprocal cube incidences, 19 nonempty cube profiles reduced to eight principals, plus product controls n=8,16,24. Earlier proofs and cumulative history preserved; pages 41-46 retain original cumulative 311-316.

Roadmap: v129 imports; v130 finite; v131 size-two; v132 odd; v133 sectors; v134 singleton; v135 p=2; v136 p=3; v137 p=4; v138 full size-four; v139 size-six impossibility; v140 size-eight interval/sectors. NEXT: exact eight-sector block closure with degree-multiset matching, using original collision as control; NOT RUN. GitHub unchanged.

Approved by direct reciprocal cube classification, principal-profile integrality, reversed-profile identity and exact sector restriction proof review; not external peer review.
