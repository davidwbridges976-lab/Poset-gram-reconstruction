from pathlib import Path
import zipfile,hashlib,json,shutil,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
ROOT=Path.cwd();R=ROOT/'output/Poset_Gram_Research_Share_v143'
# Three-page standalone entry, deliberately limited to the problem, explicit example, and current scoped result.
pdfmetrics.registerFont(TTFont('DejaVu','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));styles=getSampleStyleSheet()
for name in ['Normal','Heading1','Heading2']:styles[name].fontName='DejaVu'
styles['Normal'].fontSize=10;styles['Normal'].leading=14;styles['Heading1'].fontSize=17;styles['Heading1'].leading=23;styles['Heading2'].fontSize=12;styles['Heading2'].leading=17
pages=[[
('Heading1','Normalized upset overlaps'),('Normal','A reproducible reconstruction investigation<br/>David Bridges | Sharing snapshot from frozen v143 | 3 October 2026'),
('Heading2','The question'),('Normal','For a finite poset P, let U<sub>x</sub> = {z : x ≤ z}, including x. Set Z<sub>xy</sub> = 1[x ≤ y], d<sub>x</sub> = |U<sub>x</sub>|, K = ZZ<super>T</super> and D = diag(d).'),('Normal','G<sub>xy</sub> = |U<sub>x</sub> ∩ U<sub>y</sub>| / √(d<sub>x</sub>d<sub>y</sub>)<br/>G = D<super>-1/2</super> K D<super>-1/2</super>.'),
('Heading2','What is established'),('Normal','G alone does not determine every finite poset up to isomorphism. Page 2 gives an explicit 16-label pair with exactly equal G and a short nonisomorphism certificate. Its comparability-degree multisets differ.'),
('Normal','Supplying labeled d recovers K and the order: x ≤ y exactly when K<sub>xy</sub> = K<sub>yy</sub>. Also det(G) = 1 / ∏<sub>x</sub> d<sub>x</sub>. With positive-entry G, every realization has a unique greatest element; each possible greatest label fixes d and then a candidate order. Checking all anchors gives complete enumeration, without uniqueness.'),
('Heading2','What remains unresolved here'),('Normal','Does G together with the unordered multiset of comparability degrees determine every finite poset? A degree counts the other labels comparable to x. Recent results close specified cases (page 3); the general claim is not established. This is not a certification that the question is open in the literature.'),
('Heading2','Start in one command'),('Normal','Extract this packet and run python3 reproduce.py with Python 3.10+. Standard library only; no solver or network. It checks exact rational identities, the complete original Gram fiber, and the recent 4,356-pair class with an independent audit.'),
('Normal','Further context: github.com/davidwbridges976-lab/Poset-gram-reconstruction<br/>Detailed proof sources and scope reviews are in proofs/. No novelty or priority claim.')
],[
('Heading1','An explicit G-only counterexample'),('Normal','Use two copies E,W of the Boolean cube B<sub>3</sub>, whose vertices are subsets of {1,2,3}. Write them as masks 0,...,7, where bit k records membership. The label order is E<sub>0</sub>,...,E<sub>7</sub>,W<sub>0</sub>,...,W<sub>7</sub>.'),
('Heading2','Define the map and both orders'),('Normal','phi = [0,1,1,3,1,3,5,7].<br/>The value at index x is phi(x). This map is monotone and preserves subset size.'),
('Normal','In P, both copies use subset inclusion, and E<sub>x</sub> ≤ W<sub>y</sub> exactly when phi(x) is a subset of y. There are no W-to-E relations.'),('Normal','In Q, both copies use reverse subset inclusion, and E<sub>x</sub> ≤ W<sub>y</sub> exactly when y is a subset of phi(x). Again there are no W-to-E relations.'),
('Heading2','Why their normalized overlaps agree'),('Normal','For a cube vertex x, put u<sub>x</sub> = 2<super>3-|x|</super>, e<sub>x</sub> = 2<super>|x|</super>. P upset sizes are 2u<sub>x</sub> on E and u<sub>x</sub> on W; Q sizes are 2e<sub>x</sub> on E and e<sub>x</sub> on W. Cube upset intersections have size 2<super>3-|x ∪ y|</super>; downset intersections have size 2<super>|x ∩ y|</super>. Their normalized overlaps agree. Rank preservation lets the same identity verify every block involving phi.'),
('Heading2','Why the orders are not isomorphic'),('Normal','Among elements with upset size two, the multisets of downset sizes are:<br/>P: {5,8,9,10}<br/>Q: {6,7,8,11}.<br/>Order isomorphism preserves both sizes, so these are nonisomorphic. This is an exact collision, not a relabeling.'),
('Normal','The exact comparability-degree multisets also differ. The code verifies all 256 squared Gram entries by rational arithmetic and checks every possible greatest anchor. The entire original labeled Gram fiber has exactly these two realizations; either degree multiset selects its corresponding member in this fiber.'),
('Normal','Data: code/core/core/counterexample_input.json.<br/>Verification: code/core/verify_counterexample.py and the original anchor-audit scripts, invoked by reproduce.py.')
],[
('Heading1','Recent scoped progress'),('Normal','These results concern positive-entry G and a valid alternative greatest anchor b whose original P upset has size eight. They do not assert reconstruction for all posets.'),
('Heading2','The structural reduction'),('Normal','The anchor interval is B<sub>3</sub>, reversed in Q. Every label has one of eight principal cube-overlap profiles. Both orders preserve each sector order and have opposite allowed cube-sector directions. Exact block equations test Gram equality; endpoint factors constrain the attachments.'),
('Normal','Let R<sub>0</sub> and R<sub>7</sub> be the empty/full profile sectors. Under endpoint saturation n = 8|R<sub>0</sub>| = 8|R<sub>7</sub>|, both orders have a common base assignment partitioning labels into eight-label fibers. Relations preserve a common base order. The exact fiber lemma is analytic for every finite base size.'),
('Heading2','Complete degree-filter closures'),('Normal','For one or two base labels, matching unordered degrees forces isomorphism. The two-base class reduces completely to 66 monotone rank-preserving cube maps: 30 match degrees, and all 30 have verified isomorphisms.'),
('Normal','For the three-base order with two incomparable lower labels and one greatest, every candidate reduces to a pair of those maps. All 4,356 ordered pairs were checked: 1,068 match degrees, all with exact isomorphisms. Independent canonical forms and degree formulas agree. The proof establishes coverage of this class; this is not all 24-label posets.'),
('Heading2','Open boundaries'),('Normal','The three-chain base, larger bases, unsaturated size-eight cases, larger anchor intervals and multiple maxima remain unresolved here. The original G-only counterexample survives. There is no general G-plus-degree theorem in this packet.'),
('Heading2','Reproduction and proof map'),('Normal','Run python3 reproduce.py. The final line reports PASS for the core, all 4,356 pairs and independent audit. Complete ledgers and explicit bijections regenerate under code/three_base/results/. The retained REPRODUCTION_RUN.json is an actual execution record for this sharing edition.'),
('Normal','For the latest coverage proof, read proofs/06_three_base_degree_closure.md. proofs/README.md maps its dependencies. provenance/ documents the portable adaptation and hashes of unchanged original sources. SHA256SUMS.txt verifies the sharing packet. The full historical archive is not needed to run it.')
]]
story=[]
for page,items in enumerate(pages):
 if page:story.append(PageBreak())
 for style,text in items:story.extend([Paragraph(text,styles[style]),Spacer(1,8)])
def footer(c,d):
 c.setFont('DejaVu',8);c.drawString(48,24,'Poset Gram research | Sharing edition | Frozen source v143');c.drawRightString(564,24,str(d.page))
SimpleDocTemplate(str(R/'START_HERE.pdf'),pagesize=(612,792),leftMargin=48,rightMargin=48,topMargin=38,bottomMargin=44).build(story,onFirstPage=footer,onLaterPages=footer)
from pypdf import PdfReader
assert len(PdfReader(R/'START_HERE.pdf').pages)==3
print(json.dumps({'packet_root':str(R),'entry_pdf_pages':3,'source_integrity':'PASS'}))
