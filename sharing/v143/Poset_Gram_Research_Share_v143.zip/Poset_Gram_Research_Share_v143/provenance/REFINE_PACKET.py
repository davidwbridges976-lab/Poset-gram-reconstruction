from pathlib import Path
import shutil
root=Path.cwd();r=root/'output/Poset_Gram_Research_Share_v143'
p=r/'reproduce.py';s=p.read_text();needle="(root/'REPRODUCTION_RUN.json').write_text"
extra="""# Compare all mathematical/status fields against the frozen original outputs; timings may vary.
for name in ['exact_output.json','independent_output.json']:
 expected=json.loads((root/'provenance/original_v143'/name).read_text())
 actual=json.loads((root/'code/three_base/results'/name).read_text())
 assert {k:v for k,v in actual.items() if k!='seconds'}=={k:v for k,v in expected.items() if k!='seconds'}
"""
assert needle in s;p.write_text(s.replace(needle,extra+needle))
p=r/'README.md';s=p.read_text().replace('- SHA256SUMS.txt: integrity inventory for this sharing edition.','- SHA256SUMS.txt: integrity inventory for the distributed snapshot; rerunning changes execution outputs.');p.write_text(s)
src=Path('tmp/build_reddit_packet.py').read_text();header=src[:src.index('ROOT=Path.cwd()')];suffix=src[src.index('# Three-page standalone entry'):]
replacements={
'U_x={z:x<=z}':'U<sub>x</sub> = {z : x ≤ z}',
'Z_xy=1[x<=y]':'Z<sub>xy</sub> = 1[x ≤ y]',
'd_x=|U_x|':'d<sub>x</sub> = |U<sub>x</sub>|',
'K=ZZ^T':'K = ZZ<super>T</super>',
'D=diag(d)':'D = diag(d)',
'G_xy = |U_x intersect U_y| / sqrt(d_x d_y)':'G<sub>xy</sub> = |U<sub>x</sub> ∩ U<sub>y</sub>| / √(d<sub>x</sub>d<sub>y</sub>)',
'G = D^(-1/2) K D^(-1/2).':'G = D<super>-1/2</super> K D<super>-1/2</super>.',
'x<=y exactly when K_xy=K_yy':'x ≤ y exactly when K<sub>xy</sub> = K<sub>yy</sub>',
'det(G)=1/product_x d_x':'det(G) = 1 / ∏<sub>x</sub> d<sub>x</sub>',
'E_0,...,E_7,W_0,...,W_7':'E<sub>0</sub>,...,E<sub>7</sub>,W<sub>0</sub>,...,W<sub>7</sub>',
'E_x<=W_y':'E<sub>x</sub> ≤ W<sub>y</sub>',
'B_3':'B<sub>3</sub>',
'u_x=2^(3-|x|), e_x=2^|x|':'u<sub>x</sub> = 2<super>3-|x|</super>, e<sub>x</sub> = 2<super>|x|</super>',
'2u_x':'2u<sub>x</sub>',
'u_x on W':'u<sub>x</sub> on W',
'2e_x':'2e<sub>x</sub>',
'e_x on W':'e<sub>x</sub> on W',
'2^(3-|x union y|)':'2<super>3-|x ∪ y|</super>',
'2^|x intersect y|':'2<super>|x ∩ y|</super>',
'R_0 and R_7':'R<sub>0</sub> and R<sub>7</sub>',
'n=8|R_0|=8|R_7|':'n = 8|R<sub>0</sub>| = 8|R<sub>7</sub>|',
'U_phi(x)':'U<sub>φ(x)</sub>'
}
for a,b in replacements.items():suffix=suffix.replace(a,b)
Path('tmp/refine_share_pdf.py').write_text(header+"ROOT=Path.cwd();R=ROOT/'output/Poset_Gram_Research_Share_v143'\n"+suffix)
shutil.copy(__file__,r/'provenance/REFINE_PACKET.py');shutil.copy('tmp/refine_share_pdf.py',r/'provenance/REFINE_ENTRY_PDF.py')
