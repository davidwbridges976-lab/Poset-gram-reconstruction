from pathlib import Path
import shutil,json,hashlib,zipfile,subprocess,sys,time
ROOT=Path.cwd();R=ROOT/'output/Poset_Gram_Research_Share_v143';out=ROOT/'output/Poset_Gram_Research_Share_v143.zip';shutil.copy(__file__,R/'provenance/FINALIZE_PACKET.py')
def build():
 manifest=R/'SHA256SUMS.txt';manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(R))+'\n' for p in sorted(R.rglob('*')) if p.is_file() and p!=manifest))
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(R.rglob('*')):
   if p.is_file():z.write(p,str(Path(R.name)/p.relative_to(R)))
 with zipfile.ZipFile(out) as z:
  assert z.testzip() is None
  for line in z.read(R.name+'/SHA256SUMS.txt').decode().splitlines():
   h,p=line.split('  ',1);assert hashlib.sha256(z.read(R.name+'/'+p)).hexdigest()==h
build()
test=ROOT/'tmp/reddit_fresh_extraction';assert not test.exists();test.mkdir()
with zipfile.ZipFile(out) as z:z.extractall(test)
fresh=test/R.name
for line in (fresh/'SHA256SUMS.txt').read_text().splitlines():
 h,p=line.split('  ',1);assert hashlib.sha256((fresh/p).read_bytes()).hexdigest()==h
start=time.perf_counter();run=subprocess.run([sys.executable,str(fresh/'reproduce.py')],cwd=test,text=True,capture_output=True)
assert run.returncode==0,run.stderr
(R/'provenance/FRESH_EXTRACTION_TEST.json').write_text(json.dumps({'exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr,'seconds':time.perf_counter()-start,'before_run_all_distributed_hashes':'PASS','fresh_extraction_run':'PASS','visual_review':'PASS: all three final entry PDF pages rendered and inspected','historical_v143_checkpoint':'UNCHANGED','new_mathematical_attack':'NONE'},indent=2)+'\n')
# Only the fresh-extraction validation record is added after the test; all code and inputs are the tested bytes.
build()
pdf=ROOT/'output/Poset_Gram_Research_Overview_v143.pdf';shutil.copy(R/'START_HERE.pdf',pdf)
source=json.loads((R/'provenance/SOURCE_MAP.json').read_text())
assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==v['sha256'] for p,v in source['retained_original_files'].items())
print(json.dumps({'zip':str(out),'bytes':out.stat().st_size,'pdf_pages':3,'fresh_extraction_reproduction':'PASS','CRC_and_SHA256':'PASS','original_source_hashes':'PASS','files':sum(p.is_file() for p in R.rglob('*'))}))
