from pathlib import Path
import zipfile,hashlib,json,shutil,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
ROOT=Path.cwd();R=ROOT/'output/Poset_Gram_Research_Share_v143';assert not R.exists()
R.mkdir();(R/'provenance').mkdir();(R/'proofs').mkdir();(R/'code').mkdir()
parent=ROOT/'output/Audit10_Endpoint_Saturated_Three_Base_Vee_Degree_Filter_v143_FROZEN.zip'
with zipfile.ZipFile(parent) as z:
 assert z.testzip() is None
 for line in z.read('PACKET_SHA256.txt').decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest
 copied={}
 def copy(source,dest):
  target=R/dest;target.parent.mkdir(parents=True,exist_ok=True);raw=z.read(source);target.write_bytes(raw);copied[dest]={'source':source,'sha256':hashlib.sha256(raw).hexdigest()}
 core='02_REPRODUCE/CORE/'
 for name in z.namelist():
  if name.startswith(core) and not name.endswith('/') and not name.endswith('README.md'):
   copy(name,'code/core/'+name[len(core):])
 base='04_NEW_STRUCTURAL_RESULTS/'
 notes=[('Size_Four_All_Extreme_Sizes_Boolean_Factor_Rigidity_v138','01_boolean_factor.md'),('Size_Six_Anchor_Interval_Reciprocity_Exclusion_v139','02_anchor_interval.md'),('Size_Eight_Boolean_Interval_Eight_Sector_Reduction_v140','03_cube_and_sectors.md'),('Eight_Sector_Exact_Block_Closure_Degree_Filter_v141','04_block_equations.md'),('Endpoint_Saturated_Eight_Fibers_Two_Base_Degree_Classification_v142','05_saturated_fibers_and_two_base.md'),('Endpoint_Saturated_Three_Base_Vee_Degree_Filter_v143','06_three_base_degree_closure.md')]
 for name,dest in notes:
  copy(base+name+'/REPORT.md','proofs/'+dest)
  copy(base+name+'/FREEZE_SCOPE_REVIEW.md','proofs/review/'+dest)
 recent=base+'Endpoint_Saturated_Three_Base_Vee_Degree_Filter_v143/'
 for file in ['verify.py','independent_verify.py','exact_output.json','independent_output.json']:
  copy(recent+file,'provenance/original_v143/'+file)
 for file in ['v142_map_certificates.json','original_counterexample_input.json']:
  copy(recent+file,'code/three_base/data/'+file)
 original=z.read(recent+'verify.py').decode();independent=z.read(recent+'independent_verify.py').decode()
start=original.index("R=Path(__file__).resolve().parent;ROOT=R.parents[1]");end=original.index("maps=[x['phi']")
portable=original[:start]+'''# Reader adaptation: local inputs replace the parent-archive integrity/materialization preamble.
R=Path(__file__).resolve().parent/'results';R.mkdir(exist_ok=True)
data=Path(__file__).resolve().parent/'data'
start=time.perf_counter()
raw=(data/'v142_map_certificates.json').read_bytes();(R/'v142_map_certificates.json').write_bytes(raw)
oldraw=(data/'original_counterexample_input.json').read_bytes();(R/'original_counterexample_input.json').write_bytes(oldraw)
''' +original[end:]
(R/'code/three_base/verify.py').write_text(portable)
old="R=Path(__file__).resolve().parent;start=time.perf_counter()";assert old in independent
(R/'code/three_base/independent_verify.py').write_text(independent.replace(old,"# Reader adaptation: use the local reader-result directory.\nR=Path(__file__).resolve().parent/'results';start=time.perf_counter()"))
(R/'reproduce.py').write_text('''"""Standalone reader runner, newly executed for this sharing edition."""
from pathlib import Path
import subprocess,sys,json,time
root=Path(__file__).resolve().parent
start=time.perf_counter();records=[]
for name in ['code/core/run_all.py','code/three_base/verify.py','code/three_base/independent_verify.py']:
 result=subprocess.run([sys.executable,str(root/name)],capture_output=True,text=True)
 records.append({'script':name,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
 print(result.stdout.strip())
 if result.returncode:
  print(result.stderr,file=sys.stderr);raise SystemExit(result.returncode)
(root/'REPRODUCTION_RUN.json').write_text(json.dumps({'all_passed':True,'runs':records,'seconds':time.perf_counter()-start},indent=2)+'\\n')
print('PASS: core counterexample and fiber; all 4,356 three-base pairs; independent degree and isomorphism audit.')
''')
(R/'README.md').write_text('''# Normalized upset overlaps: a reproducible reconstruction investigation

David Bridges | Sharing snapshot, 3 October 2026 | Based on frozen v143

**Start with START_HERE.pdf (3 pages).** This packet includes an explicit counterexample, exact verification code, and recent scoped results. No novelty or priority claim is made.

For a finite poset, let U_x contain x and everything above it. We study the matrix

    G(x,y) = |U_x intersect U_y| / sqrt(|U_x| |U_y|).

**Known failure:** G alone does not determine every finite poset up to isomorphism. The included 16-label orders have exactly the same G and are nonisomorphic. Their comparability-degree multisets differ. Both G-only ambiguity and the unequal degree data are reproduced here.

**Open question in this investigation:** does G together with the unordered comparability-degree multiset determine every finite poset? This packet does not establish that it does, or certify that the question is open in the literature.

**Recent scoped results:** with positive-entry G, original alternative-anchor upset size eight, and endpoint saturation, degree matching forces isomorphism for one or two base labels, and for the three-base order with two incomparable lower labels and one greatest. The two-base class has 66 map representations, 30 degree matches; the latter three-base class has 4,356 ordered map pairs, 1,068 degree matches. Every matched pair is isomorphic. These are complete specified classes, not exhaustive populations of all 16- or 24-element posets. The three-chain base and broader classes remain unresolved.

## Reproduce

Python 3.10+; standard library only. Extract the ZIP, open a terminal in this folder, then run:

    python3 reproduce.py

No solver, installation or network is needed. The runner checks the counterexample, its entire positive-entry Gram fiber, the scale audit, all 4,356 recent class representations and an independent canonical-form calculation. It regenerates complete gzip ledgers and explicit isomorphism certificates. Run normally, without Python's -O option: verification uses assertions. REPRODUCTION_RUN.json records this edition's actual execution.

## Reading map

- START_HERE.pdf: the question, counterexample and recent scoped result.
- proofs/README.md: optional proof/dependency map; source proof reports and frozen scope reviews.
- code/: exact core sources and a documented portable adaptation of the recent verifier.
- provenance/: original verifier, original outputs, source hashes and adaptation notes.
- SHA256SUMS.txt: integrity inventory for this sharing edition.

Repository for further context: https://github.com/davidwbridges976-lab/Poset-gram-reconstruction

This sharing edition is independently runnable. The repository link is optional context; no repository update or Reddit post was made when creating it. The historical research archive is outside this concise edition.
''')
(R/'proofs/README.md').write_text('''# Optional proof notes

For the latest result, read 06_three_base_degree_closure.md, especially its coverage and intrinsic-isomorphism arguments. The corresponding frozen scope review is in review/. The three-page entry PDF stands on its own as an overview; these are detailed proof sources.

Dependency order, if you want to audit the reduction:

1. 01_boolean_factor.md: Boolean-factor lemma and its induction proof. Its separate size-four application is additional context.
2. 02_anchor_interval.md: general interval reciprocity/reversal lemma. The size-six exclusion is additional context.
3. 03_cube_and_sectors.md: cube interval, principal profiles and sector transport.
4. 04_block_equations.md: complete block test and endpoint factors.
5. 05_saturated_fibers_and_two_base.md: common eight-label fibers and complete two-base coverage.
6. 06_three_base_degree_closure.md: complete two-map coverage, degree filter and intrinsic isomorphism test.

Reports are copied unchanged from the frozen v143 packet and retain their original pre-freeze dates/status wording. The adjacent review/ files record their frozen scope. These notes include scoped assumptions and earlier corrections; they are not a general uniqueness theorem, external peer review or novelty certification.
''')
(R/'provenance/ADAPTATION.md').write_text('''# Sharing edition provenance

The source is the verified frozen v143 ZIP, named in SOURCE_MAP.json. Every retained original file is copied byte-for-byte, with its SHA256 and source path recorded there. The core verifiers are unchanged.

code/three_base/verify.py is a NEW portable adaptation, executed for this edition. Only the archive-verification/input-extraction preamble is replaced with local input reads and a local results directory. The mathematical construction and checks are unchanged. code/three_base/independent_verify.py changes only its result-directory path. The exact original programs and outputs remain under original_v143/. Those originals require the historical parent ZIP for their original workflow; use the root reproduce.py to run this standalone edition.

reproduce.py and BUILD_PACKET.py are new convenience/authoring programs, executed for this edition. They are not mislabeled as historical source. No new mathematical attack or canonical checkpoint is created. Timing is machine-dependent. Full generated ledgers are included under code/three_base/results/ after execution.
''')
(R/'provenance/SOURCE_MAP.json').write_text(json.dumps({'parent_name':parent.name,'parent_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'parent_integrity':'CRC and all manifest hashes PASS','retained_original_files':copied},indent=2)+'\n')
shutil.copy(__file__,R/'provenance/BUILD_PACKET.py')
# Three-page standalone entry, deliberately limited to the problem, explicit example, and current scoped result.
pdfmetrics.registerFont(TTFont('DejaVu','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'));styles=getSampleStyleSheet()
for name in ['Normal','Heading1','Heading2']:styles[name].fontName='DejaVu'
styles['Normal'].fontSize=10;styles['Normal'].leading=14;styles['Heading1'].fontSize=17;styles['Heading1'].leading=23;styles['Heading2'].fontSize=12;styles['Heading2'].leading=17
pages=[[
('Heading1','Normalized upset overlaps'),('Normal','A reproducible reconstruction investigation<br/>David Bridges | Sharing snapshot from frozen v143 | 3 October 2026'),
('Heading2','The question'),('Normal','For a finite poset P, let U_x={z:x<=z}, including x. Set Z_xy=1[x<=y], d_x=|U_x|, K=ZZ^T and D=diag(d).'),('Normal','G_xy = |U_x intersect U_y| / sqrt(d_x d_y)<br/>G = D^(-1/2) K D^(-1/2).'),
('Heading2','What is established'),('Normal','G alone does not determine every finite poset up to isomorphism. Page 2 gives an explicit 16-label pair with exactly equal G and a short nonisomorphism certificate. Its comparability-degree multisets differ.'),
('Normal','Supplying labeled d recovers K and the order: x<=y exactly when K_xy=K_yy. Also det(G)=1/product_x d_x. With positive-entry G, every realization has a unique greatest element; each possible greatest label fixes d and then a candidate order. Checking all anchors gives complete enumeration, without uniqueness.'),
('Heading2','What remains unresolved here'),('Normal','Does G together with the unordered multiset of comparability degrees determine every finite poset? A degree counts the other labels comparable to x. Recent results close specified cases (page 3); the general claim is not established. This is not a certification that the question is open in the literature.'),
('Heading2','Start in one command'),('Normal','Extract this packet and run python3 reproduce.py with Python 3.10+. Standard library only; no solver or network. It checks exact rational identities, the complete original Gram fiber, and the recent 4,356-pair class with an independent audit.'),
('Normal','Further context: github.com/davidwbridges976-lab/Poset-gram-reconstruction<br/>Detailed proof sources and scope reviews are in proofs/. No novelty or priority claim.')
],[
('Heading1','An explicit G-only counterexample'),('Normal','Use two copies E,W of the Boolean cube B_3, whose vertices are subsets of {1,2,3}. Write them as masks 0,...,7, where bit k records membership. The label order is E_0,...,E_7,W_0,...,W_7.'),
('Heading2','Define the map and both orders'),('Normal','phi = [0,1,1,3,1,3,5,7].<br/>The value at index x is phi(x). This map is monotone and preserves subset size.'),
('Normal','In P, both copies use subset inclusion, and E_x<=W_y exactly when phi(x) is a subset of y. There are no W-to-E relations.'),('Normal','In Q, both copies use reverse subset inclusion, and E_x<=W_y exactly when y is a subset of phi(x). Again there are no W-to-E relations.'),
('Heading2','Why their normalized overlaps agree'),('Normal','For a cube vertex x, put u_x=2^(3-|x|), e_x=2^|x|. P upset sizes are 2u_x on E and u_x on W; Q sizes are 2e_x on E and e_x on W. Cube upset intersections have size 2^(3-|x union y|); downset intersections have size 2^|x intersect y|. Their normalized overlaps agree. Rank preservation lets the same identity verify every block involving phi.'),
('Heading2','Why the orders are not isomorphic'),('Normal','Among elements with upset size two, the multisets of downset sizes are:<br/>P: {5,8,9,10}<br/>Q: {6,7,8,11}.<br/>Order isomorphism preserves both sizes, so these are nonisomorphic. This is an exact collision, not a relabeling.'),
('Normal','The exact comparability-degree multisets also differ. The code verifies all 256 squared Gram entries by rational arithmetic and checks every possible greatest anchor. The entire original labeled Gram fiber has exactly these two realizations; either degree multiset selects its corresponding member in this fiber.'),
('Normal','Data: code/core/core/counterexample_input.json.<br/>Verification: code/core/verify_counterexample.py and the original anchor-audit scripts, invoked by reproduce.py.')
],[
('Heading1','Recent scoped progress'),('Normal','These results concern positive-entry G and a valid alternative greatest anchor b whose original P upset has size eight. They do not assert reconstruction for all posets.'),
('Heading2','The structural reduction'),('Normal','The anchor interval is B_3, reversed in Q. Every label has one of eight principal cube-overlap profiles. Both orders preserve each sector order and have opposite allowed cube-sector directions. Exact block equations test Gram equality; endpoint factors constrain the attachments.'),
('Normal','Let R_0 and R_7 be the empty/full profile sectors. Under endpoint saturation n=8|R_0|=8|R_7|, both orders have a common base assignment partitioning labels into eight-label fibers. Relations preserve a common base order. The exact fiber lemma is analytic for every finite base size.'),
('Heading2','Complete degree-filter closures'),('Normal','For one or two base labels, matching unordered degrees forces isomorphism. The two-base class reduces completely to 66 monotone rank-preserving cube maps: 30 match degrees, and all 30 have verified isomorphisms.'),
('Normal','For the three-base order with two incomparable lower labels and one greatest, every candidate reduces to a pair of those maps. All 4,356 ordered pairs were checked: 1,068 match degrees, all with exact isomorphisms. Independent canonical forms and degree formulas agree. The proof establishes coverage of this class; this is not all 24-label posets.'),
('Heading2','Open boundaries'),('Normal','The three-chain base, larger bases, unsaturated size-eight cases, larger anchor intervals and multiple maxima remain unresolved here. The original G-only counterexample survives. There is no general G-plus-degree theorem in this packet.'),
('Heading2','Reproduction and proof map'),('Normal','Run python3 reproduce.py. The final line reports PASS for the core, all 4,356 pairs and independent audit. Complete ledgers and explicit bijections regenerate under code/three_base/results/. The retained REPRODUCTION_RUN.json is an actual execution record for this sharing edition.'),
('Normal','For the latest coverage proof, read proofs/06_three_base_degree_closure.md. proofs/README.md maps its dependencies. provenance/ documents the portable adaptation and hashes of unchanged original sources. SHA256SUMS.txt verifies the sharing packet. The full historical archive is not needed to run it.')
]]
story=[]
for page,items in enumerate(pages):
 if page:story.append(PageBreak())
 for style,text in items:story.extend([Paragraph(text,styles[style]),Spacer(1,8)])
def footer(c,d):
 c.setFont('DejaVu',8);c.drawString(48,24,'Poset Gram research | Sharing edition | Frozen source v143');c.drawRightString(564,24,str(d.page))
SimpleDocTemplate(str(R/'START_HERE.pdf'),pagesize=(612,792),leftMargin=48,rightMargin=48,topMargin=38,bottomMargin=44).build(story,onFirstPage=footer,onLaterPages=footer)
from pypdf import PdfReader
assert len(PdfReader(R/'START_HERE.pdf').pages)==3
print(json.dumps({'packet_root':str(R),'entry_pdf_pages':3,'source_integrity':'PASS'}))
