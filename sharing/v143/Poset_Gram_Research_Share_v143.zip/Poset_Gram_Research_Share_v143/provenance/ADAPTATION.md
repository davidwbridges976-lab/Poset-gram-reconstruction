# Sharing edition provenance

The source is the verified frozen v143 ZIP, named in SOURCE_MAP.json. Every retained original file is copied byte-for-byte, with its SHA256 and source path recorded there. The core verifiers are unchanged.

code/three_base/verify.py is a NEW portable adaptation, executed for this edition. Only the archive-verification/input-extraction preamble is replaced with local input reads and a local results directory. The mathematical construction and checks are unchanged. code/three_base/independent_verify.py changes only its result-directory path. The exact original programs and outputs remain under original_v143/. Those originals require the historical parent ZIP for their original workflow; use the root reproduce.py to run this standalone edition.

reproduce.py and BUILD_PACKET.py are new convenience/authoring programs, executed for this edition. They are not mislabeled as historical source. No new mathematical attack or canonical checkpoint is created. Timing is machine-dependent. Full generated ledgers are included under code/three_base/results/ after execution.
