# Exact n15 Test Timed Rerun

The original driver and unchanged frozen v74 engine were copied into a fresh directory. Driver, engine, generated inputs, and protocol were compared byte-for-byte with the first attempt: all matched.

All 68 target-match checks succeeded again. All 561 base-input pairs were screened with exact rational squared-Gram entry multisets; each pair was distinguished, so no weighted-graph isomorphism calls were needed. This is the same bounded population, not exhaustive or unique-reconstruction evidence.

External process-launch-to-exit wall time: 0.6179318439999406 seconds.
Internal timed section: 0.418709712999771 seconds.

The external time includes Python startup/imports, engine hash verification, population generation, input/protocol writing, all 68 isolated calls, collision screening, and output writing. It excludes dependency installation, copying files, and packet packaging. The internal timer starts after generation and input/protocol writing. These are single-run measurements on the recorded modern environment, not estimates for arbitrary n=15 inputs or exhaustive enumeration.

Executed wrapper: time_process.py. Original experimental driver: run_attempt.py. Fresh raw outputs and environment are retained. No prior output was overwritten. No public repository or canonical research checkpoint was modified.
