"""Executed bounded n=15 experiment, original frozen engine unchanged."""
import os,json,time,hashlib,random,sys,platform,multiprocessing as mp
from pathlib import Path
from fractions import Fraction
import numpy as np,networkx as nx
import frozen_engine_v74 as engine
ROOT=Path(__file__).resolve().parent
SEED=20260930

def closure(n,edges):
 Z=np.eye(n,dtype=np.int8)
 for i,j in edges:Z[i,j]=1
 for k in range(n):
  for i in range(n):
   if Z[i,k]:Z[i,:]|=Z[k,:]
 return Z

def worker(G,Z,q):
 try:q.put({'matched':bool(engine.optimized_engine_from_G(G,Z))})
 except Exception as e:q.put({'error':repr(e)})

def exact_graph(Z):
 K=Z.astype(int)@Z.astype(int).T;d=np.diag(K);g=nx.Graph();g.add_nodes_from(range(15))
 weights=[]
 for i in range(15):
  for j in range(i+1,15):
   w=Fraction(int(K[i,j])**2,int(d[i])*int(d[j]));s=str(w);g.add_edge(i,j,q=s);weights.append(s)
 return g,tuple(sorted(weights))

def main():
 source=(ROOT/'frozen_engine_v74.py').read_bytes();assert hashlib.sha256(source).hexdigest()=='ef5a91e87597da0cfaa2869d10f8aae0978d3880123db5ae40d6d7a085de4040'
 rng=random.Random(SEED);pop=[]
 pop.append(('antichain',closure(15,[])))
 pop.append(('chain',closure(15,[(i,i+1) for i in range(14)])))
 pop.append(('height2_complete_7_8',closure(15,[(i,j) for i in range(7) for j in range(7,15)])))
 pop.append(('two_chains_7_8',closure(15,[(i,i+1) for i in range(6)]+[(i,i+1) for i in range(7,14)])))
 for fam in ('height2','three_layer','ordered_dag'):
  for k in range(10):
   p=(.1,.3,.5,.7,.9)[k%5]
   def eligible(i,j):
    if fam=='height2':return i<7<=j
    if fam=='three_layer':return i//5<j//5
    return True
   edges=[(i,j) for i in range(15) for j in range(i+1,15) if eligible(i,j) and rng.random()<p]
   pop.append((f'{fam}_{k}_p{p}',closure(15,edges)))
 cases=[]
 for i,(name,Z) in enumerate(pop):
  cases.append({'base':i,'name':name,'permutation':list(range(15)),'Z':Z.tolist()})
  perm=list(range(15));rng.shuffle(perm)
  cases.append({'base':i,'name':name+'_relabeled','permutation':perm,'Z':Z[np.ix_(perm,perm)].tolist()})
 protocol={'seed':SEED,'n':15,'base_cases':34,'calls':68,'per_call_seconds':5,'overall_seconds':120,'source_sha256':hashlib.sha256(source).hexdigest(),'scope':'bounded fixed population; not exhaustive; original boolean engine; exact collision comparison separate'}
 (ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');(ROOT/'inputs.json').write_text(json.dumps(cases)+'\n')
 records=[];start=time.monotonic()
 for i,c in enumerate(cases):
  if time.monotonic()-start>=120:records.append({'case':i,'status':'NOT_RUN_OVERALL_BUDGET'});continue
  Z=np.array(c['Z'],dtype=np.int8);_,G=engine.exact_q_and_G(Z);q=mp.Queue();proc=mp.Process(target=worker,args=(G,Z,q));t=time.monotonic();proc.start();proc.join(min(5,max(0,120-(time.monotonic()-start))))
  if proc.is_alive():proc.terminate();proc.join();result={'status':'TIMEOUT'}
  elif not q.empty():
   result=q.get();result['status']='ERROR' if 'error'in result else ('MATCH' if result['matched'] else 'NO_MATCH')
  else:result={'status':'WORKER_NO_OUTPUT','exitcode':proc.exitcode}
  rec={'case':i,'name':c['name'],'seconds_including_process_overhead':time.monotonic()-t,**result};records.append(rec)
  with (ROOT/'raw.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
 graphdata=[exact_graph(Z) for _,Z in pop];tested=0;equal=[];collisions=[]
 for i in range(34):
  for j in range(i+1,34):
   if graphdata[i][1]!=graphdata[j][1]:continue
   tested+=1
   if nx.is_isomorphic(graphdata[i][0],graphdata[j][0],edge_match=nx.algorithms.isomorphism.categorical_edge_match('q',None)):
    same=engine.iso(pop[i][1],pop[j][1]);equal.append({'i':i,'j':j,'poset_isomorphic':same})
    if not same:collisions.append({'i':i,'j':j})
 from collections import Counter
 summary={'status_counts':dict(Counter(r['status'] for r in records)),'elapsed_seconds':time.monotonic()-start,'collision_pairs_screened':561,'exact_G_graph_isomorphism_checks':tested,'equal_G_pairs':equal,'nonisomorphic_G_collisions':collisions,'environment':{'python':sys.version,'numpy':np.__version__,'networkx':nx.__version__,'platform':platform.platform()},'meaning':'MATCH means existence of a candidate isomorphic to known target; not uniqueness. NO_MATCH is implementation non-recovery, not a G collision.'}
 (ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
