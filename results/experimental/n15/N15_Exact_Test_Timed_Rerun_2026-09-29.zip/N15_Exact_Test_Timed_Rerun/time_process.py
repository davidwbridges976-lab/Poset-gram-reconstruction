"""Executed external process timer for an unchanged experimental driver."""
import subprocess,time,json,sys,os
from pathlib import Path
root=Path(__file__).resolve().parent
env=os.environ.copy();env['PYTHONPATH']='/tmp/n15-deps';env['OPENBLAS_NUM_THREADS']='1'
t=time.perf_counter()
with (root/'execution.txt').open('w') as out:
 result=subprocess.run([sys.executable,str(root/'run_attempt.py')],env=env,stdout=out,stderr=subprocess.STDOUT)
elapsed=time.perf_counter()-t
record={'total_process_wall_seconds':elapsed,'exit_code':result.returncode,'scope':'launch through exit including interpreter/imports, source verification, generation, all 68 calls, exact collision screening, output writes; excludes setup/copying and subsequent packaging'}
(root/'process_timing.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
if result.returncode:raise SystemExit(result.returncode)
