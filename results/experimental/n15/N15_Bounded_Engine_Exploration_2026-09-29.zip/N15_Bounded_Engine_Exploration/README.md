# Bounded n15 Engine Exploration

Completed experimental attempt using the unchanged frozen Track A v74 engine.

Result: 68/68 calls returned target matches across 34 base posets on 15 elements and one seeded relabeling of each. No timeout or engine error occurred. This is finite implementation evidence, not arbitrary-n injectivity or exhaustive coverage.

Population: antichain, chain, complete height-two 7-by-8 order, disjoint chains of sizes 7 and 8, plus ten seeded examples each from height-two, three-layer, and ordered-DAG transitive-closure generators. Edge probabilities cycle through 0.1, 0.3, 0.5, 0.7, and 0.9. Seed 20260930. The population is structured and biased, not a uniform random sample of all posets.

Budgets fixed before execution: 68 calls, five seconds per call, 120 seconds overall. All calls completed. Process-overhead-inclusive times are fresh measurements and are not comparable to the frozen historical medians.

Exact collision screen: 561 pairs among the 34 base inputs. For each input, integer K=ZZ^T and diagonal sizes determine exact rational squared normalized entries K_ij^2/(d_i*d_j). All off-diagonal entry-multiset signatures differ between base inputs; since permutation preserves this multiset, no two base inputs have permutation-equivalent G. Thus zero pairs advanced to weighted-graph isomorphism. Relabelings are intentionally equivalent and excluded from the base-pair collision screen. Squaring loses no information because these Gram entries are nonnegative.

The engine returns a boolean that at least one retained candidate matches the known target. It does not expose all candidates, certify unique reconstruction, or establish that every retained candidate is valid. No collision or engine failure was found in this sample; this is not an all-n result.

Provenance: original v74 source SHA-256 ef5a91e87597da0cfaa2869d10f8aae0978d3880123db5ae40d6d7a085de4040 verified before execution. Original v74/v80 archives and repository packaging audit were checked as the computational branch anchor. This attempt does not resume or modify the wider mathematical audit. No historical artifact, source, or public repository was changed.

Executed files: run_attempt.py (new experimental driver), frozen_engine_v74.py (exact original), protocol.json, inputs.json, raw.jsonl, summary.json, execution.txt. initial_dependency_failure.txt preserves the initial import failure before NetworkX installation; that failed start executed zero cases. Recorded environment is modern, not claimed to reproduce historical versions.

Reproduce with Python, NumPy, and NetworkX:

    OPENBLAS_NUM_THREADS=1 python run_attempt.py

Use a fresh copied directory: raw.jsonl is append-only during a run. Preserve this packet before reproducing. Inputs and output flags, rather than wall-clock times, are the reproducibility target.

Roadmap: this bounded attempt is complete and recorded. No additional population or next attack has started. Candidate-ambiguity inspection would require a separately documented instrumented implementation and authorization; it must not be labeled the unchanged frozen engine.
